import React from "react";
import Frame from "./components/Frame";
import "./App.css";

function App() {
  const base = process.env.PUBLIC_URL || "";

  return (
    <div className="app-container">
      <Frame title="Home" htmlFile={`${base}/html/home.html`} />
      <Frame title="Login" htmlFile={`${base}/html/login.html`} />
      <Frame title="Signup" htmlFile={`${base}/html/signup.html`} />
      <Frame title="Dashboard" htmlFile={`${base}/html/dashboard.html`} />
    </div>
  );
}

export default App;
