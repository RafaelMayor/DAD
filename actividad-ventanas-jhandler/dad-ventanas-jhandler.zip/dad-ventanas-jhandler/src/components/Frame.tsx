import React, { useState } from "react";
import Modal from "./Modal";


interface FrameProps {
  title: string;
  htmlFile: string;
}

const Frame: React.FC<FrameProps> = ({ title, htmlFile }) => {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="frame">
      <h2>Diseño de {title}</h2>
      <button className="open-btn" onClick={() => setShowModal(true)}>
        Abrir ventana
      </button>
      <Modal
        show={showModal}
        onClose={() => setShowModal(false)}
        htmlPath={htmlFile}
        title={title}
      />
    </div>
  );
};

export default Frame;
