import React, { useState, useEffect } from "react";
import "./Modal.css";

interface ModalProps {
  show: boolean;
  onClose: () => void;
  htmlPath: string;
  title: string;
}

const Modal: React.FC<ModalProps> = ({ show, onClose, htmlPath, title }) => {
  const [closing, setClosing] = useState(false);

  useEffect(() => {
    if (!show) setClosing(false);
  }, [show]);

  const handleClose = () => {
    setClosing(true);
    setTimeout(() => {
      setClosing(false);
      onClose();
    }, 250); // coincide con duración del fadeOut
  };

  if (!show && !closing) return null;

  return (
    <div className={`modal-overlay ${closing ? "fadeOut" : ""}`}>
      <div className={`modal-content ${closing ? "zoomOut" : ""}`}>
        <h2 className="modal-title">{title}</h2>
        <iframe
          src={htmlPath}
          title={title}
          className="modal-iframe"
          sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        ></iframe>
        <button className="close-btn" onClick={handleClose}>
          Cerrar ventana
        </button>
      </div>
    </div>
  );
};

export default Modal;
