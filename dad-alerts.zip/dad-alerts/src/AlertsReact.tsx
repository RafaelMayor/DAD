import React from 'react';

export default function AlertsReact() {
  const showAlert = (type: string) => {
    switch (type) {
      case 'error':
        alert('Error: Ha ocurrido un problema.');
        break;
      case 'info':
        alert('Información: Todo funciona correctamente.');
        break;
      case 'warning':
        alert('Advertencia: Ten cuidado con esta acción.');
        break;
      case 'confirm':
        const confirmed = window.confirm('¿Estás seguro de continuar?');
        if (confirmed) {
          alert('Confirmado.');
        } else {
          alert('Cancelado.');
        }
        break;
      default:
        alert('Alerta desconocida.');
    }
  };

  return (
    <div>
      <h2>Ejemplo de Alertas en React</h2>
      <button onClick={() => showAlert('error')}>Mostrar Error</button>
      <button onClick={() => showAlert('info')}>Mostrar Info</button>
      <button onClick={() => showAlert('warning')}>Mostrar Warning</button>
      <button onClick={() => showAlert('confirm')}>Mostrar Confirm</button>
    </div>
  );
}