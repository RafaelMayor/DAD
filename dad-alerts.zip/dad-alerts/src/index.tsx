import React from 'react';
import ReactDOM from 'react-dom/client';
import AlertsReact from './AlertsReact';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <React.StrictMode>
    <AlertsReact />
  </React.StrictMode>
);
