# Guía de Instalación y Uso

## Instalación Rápida

1. **Instalar dependencias:**
```bash
npm install
```

2. **Ejecutar en modo desarrollo:**
```bash
npm run dev
```

## Desarrollo

La aplicación se ejecutará en modo desarrollo con:
- Hot reload habilitado
- DevTools de Electron abiertos
- Servidor webpack en http://localhost:3000

## Construcción para Producción

### Windows
```bash
npm run package:win
```

### Linux
```bash
npm run package:linux
```

### macOS
```bash
npm run package:mac
```

### Todas las plataformas
```bash
npm run package:all
```

Los ejecutables se generarán en la carpeta `release/`.

## Notas Importantes

1. **Iconos**: Para generar los ejecutables con iconos personalizados, coloca los archivos de iconos en la carpeta `assets/`:
   - `icon.ico` para Windows
   - `icon.icns` para macOS
   - `icon.png` para Linux

2. **Primera ejecución**: La primera vez que ejecutes `npm install`, puede tardar varios minutos mientras descarga todas las dependencias.

3. **Problemas comunes**:
   - Si encuentras errores de permisos en Linux/macOS, usa `sudo` cuando sea necesario
   - Si el puerto 3000 está ocupado, cierra otras aplicaciones que lo usen o cambia el puerto en `webpack.config.js`

## Estructura de Archivos Generados

Después de ejecutar `npm run build`:
- `dist/` - Contiene los archivos compilados de React y Electron
- `release/` - Contiene los ejecutables finales para distribución

## Próximos Pasos

1. Conectar con una API backend real
2. Implementar persistencia de datos (localStorage, base de datos local)
3. Agregar más funcionalidades según necesidades
4. Personalizar iconos y metadatos de la aplicación

