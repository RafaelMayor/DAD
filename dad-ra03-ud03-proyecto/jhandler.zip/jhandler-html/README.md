# jhandler - Aplicación de Escritorio

Aplicación de escritorio para gestión de recursos humanos desarrollada con React, TypeScript y Electron.

## 🚀 Características

- ✅ Interfaz moderna y responsive
- ✅ Gestión de empleados
- ✅ Gestión de ausencias (vacaciones, enfermedad, etc.)
- ✅ Gestión de nóminas
- ✅ Generación de informes
- ✅ Sistema de autenticación
- ✅ Multiplataforma (Windows, Linux, macOS)

## 📋 Requisitos Previos

- Node.js 18+ y npm
- Git

## 🛠️ Instalación

1. Clona el repositorio o navega al directorio del proyecto:
```bash
cd jhandler-html
```

2. Instala las dependencias:
```bash
npm install
```

## 🏃 Desarrollo

Para ejecutar la aplicación en modo desarrollo:

```bash
npm run dev
```

Esto iniciará:
- El servidor de desarrollo de React (puerto 3000)
- La aplicación Electron

## 📦 Construcción

### Construir para todas las plataformas:
```bash
npm run build
npm run package:all
```

### Construir para una plataforma específica:

**Windows:**
```bash
npm run package:win
```

**Linux:**
```bash
npm run package:linux
```

**macOS:**
```bash
npm run package:mac
```

Los archivos ejecutables se generarán en la carpeta `release/`.

## 📁 Estructura del Proyecto

```
jhandler-html/
├── electron/          # Código del proceso principal de Electron
│   ├── main.ts        # Proceso principal
│   └── preload.js     # Script de preload
├── src/               # Código fuente de React
│   ├── components/    # Componentes reutilizables
│   ├── contexts/      # Contextos de React (Auth, etc.)
│   ├── pages/         # Páginas de la aplicación
│   ├── styles/        # Estilos globales
│   ├── App.tsx        # Componente principal
│   └── index.tsx      # Punto de entrada
├── dist/              # Archivos compilados (generado)
└── release/           # Ejecutables finales (generado)
```

## 🎨 Páginas Disponibles

- **Login** - Inicio de sesión
- **Signup** - Registro de usuarios
- **Dashboard** - Panel principal con estadísticas
- **Empleados** - Gestión de empleados
- **Ausencias** - Gestión de ausencias y solicitudes
- **Nóminas** - Gestión de nóminas
- **Informes** - Generación de informes
- **Configuración** - Ajustes del sistema

## 🔧 Tecnologías Utilizadas

- **React 18** - Biblioteca de UI
- **TypeScript** - Tipado estático
- **Electron** - Framework para aplicaciones de escritorio
- **React Router** - Enrutamiento
- **Webpack** - Bundler
- **CSS3** - Estilos

## 📝 Notas

- La aplicación utiliza datos simulados para demostración
- En producción, deberías conectar con una API backend
- Los estilos están basados en los archivos HTML/CSS originales

## 🤝 Contribuir

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT.

## 👥 Autor

TalentoCorp S.L.

---

**Nota:** Esta aplicación fue convertida desde archivos HTML/CSS estáticos a una aplicación Electron completamente funcional.

