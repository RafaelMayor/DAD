import * as bcrypt from 'bcryptjs';
import { getDatabase, User, UserRole } from './database';

export interface AuthResult {
  success: boolean;
  user?: Omit<User, 'passwordHash'>;
  error?: string;
}

/**
 * Registra un nuevo usuario
 */
export async function registerUser(
  email: string,
  password: string,
  name: string
): Promise<AuthResult> {
  try {
    // Validaciones
    if (!email || !password || !name) {
      return {
        success: false,
        error: 'Todos los campos son requeridos'
      };
    }

    if (password.length < 6) {
      return {
        success: false,
        error: 'La contraseña debe tener al menos 6 caracteres'
      };
    }

    // Verificar si el usuario ya existe
    const db = await getDatabase();
    const existingUser = db.getUserByEmail(email);
    
    if (existingUser) {
      return {
        success: false,
        error: 'El email ya está registrado'
      };
    }

    // Hash de la contraseña
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // Crear usuario con rol Empleado por defecto
    const newUser = db.createUser(email, passwordHash, name, 'Empleado');
    
    if (!newUser) {
      return {
        success: false,
        error: 'Error al crear el usuario'
      };
    }

    // Retornar usuario sin la contraseña
    const { passwordHash: _, ...userWithoutPassword } = newUser;
    
    return {
      success: true,
      user: userWithoutPassword
    };
  } catch (error: any) {
    console.error('Error en registerUser:', error);
    return {
      success: false,
      error: error.message || 'Error al registrar usuario'
    };
  }
}

/**
 * Autentica un usuario
 */
export async function loginUser(
  email: string,
  password: string
): Promise<AuthResult> {
  try {
    // Validaciones
    if (!email || !password) {
      return {
        success: false,
        error: 'Email y contraseña son requeridos'
      };
    }

    // Buscar usuario
    const db = await getDatabase();
    const user = db.getUserByEmail(email);
    
    if (!user) {
      return {
        success: false,
        error: 'Credenciales incorrectas'
      };
    }

    // Verificar contraseña
    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    
    if (!isPasswordValid) {
      return {
        success: false,
        error: 'Credenciales incorrectas'
      };
    }

    // Retornar usuario sin la contraseña
    const { passwordHash: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      user: userWithoutPassword
    };
  } catch (error: any) {
    console.error('Error en loginUser:', error);
    return {
      success: false,
      error: error.message || 'Error al autenticar usuario'
    };
  }
}

/**
 * Obtiene un usuario por ID (sin contraseña)
 */
export async function getUserById(id: number): Promise<Omit<User, 'passwordHash'> | null> {
  try {
    const db = await getDatabase();
    const user = db.getUserById(id);
    
    if (!user) {
      return null;
    }

    const { passwordHash: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  } catch (error) {
    console.error('Error en getUserById:', error);
    return null;
  }
}

/**
 * Actualiza el perfil de un usuario
 */
export async function updateUserProfile(
  id: number,
  email: string,
  name: string,
  phone?: string,
  position?: string,
  profilePhoto?: string,
  role?: UserRole,
  department?: string
): Promise<AuthResult> {
  try {
    // Validaciones
    if (!email || !name) {
      return {
        success: false,
        error: 'Email y nombre son requeridos'
      };
    }

    const db = await getDatabase();
    
    // Verificar que el usuario existe
    const existingUser = db.getUserById(id);
    if (!existingUser) {
      return {
        success: false,
        error: 'Usuario no encontrado'
      };
    }

    // Verificar que el email no esté en uso por otro usuario
    const userWithEmail = db.getUserByEmail(email);
    if (userWithEmail && userWithEmail.id !== id) {
      return {
        success: false,
        error: 'El email ya está en uso por otro usuario'
      };
    }

    // Actualizar perfil
    const updatedUser = db.updateUserProfile(id, email, name, phone, position, profilePhoto, role, department);
    
    if (!updatedUser) {
      return {
        success: false,
        error: 'Error al actualizar el perfil'
      };
    }

    // Retornar usuario sin la contraseña
    const { passwordHash: _, ...userWithoutPassword } = updatedUser;
    
    return {
      success: true,
      user: userWithoutPassword
    };
  } catch (error: any) {
    console.error('Error en updateUserProfile:', error);
    return {
      success: false,
      error: error.message || 'Error al actualizar el perfil'
    };
  }
}

