import * as bcrypt from 'bcryptjs';
import { getDatabase, User, UserRole } from './database';

export interface AuthResult {
  success: boolean;
  user?: Omit<User, 'passwordHash'>;
  error?: string;
}

export async function registerUser(
  email: string,
  password: string,
  name: string
): Promise<AuthResult> {
  try {
    if (!email || !password || !name) {
      return {
        success: false,
        error: 'Todos los campos son requeridos'
      };
    }

    if (password.length < 6) {
      return {
        success: false,
        error: 'La contraseña debe tener al menos 6 caracteres'
      };
    }

    const db = await getDatabase();
    const existingUser = db.getUserByEmail(email);
    
    if (existingUser) {
      return {
        success: false,
        error: 'El email ya está registrado'
      };
    }

    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    const newUser = db.createUser(email, passwordHash, name, 'Empleado');
    
    if (!newUser) {
      return {
        success: false,
        error: 'Error al crear el usuario'
      };
    }

    const { passwordHash: _, ...userWithoutPassword } = newUser;
    
    return {
      success: true,
      user: userWithoutPassword
    };
  } catch (error: any) {
    console.error('Error en registerUser:', error);
    return {
      success: false,
      error: error.message || 'Error al registrar usuario'
    };
  }
}

export async function loginUser(
  email: string,
  password: string
): Promise<AuthResult> {
  try {
    if (!email || !password) {
      return {
        success: false,
        error: 'Email y contraseña son requeridos'
      };
    }

    const db = await getDatabase();
    const user = db.getUserByEmail(email);
    
    if (!user) {
      return {
        success: false,
        error: 'Credenciales incorrectas'
      };
    }

    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    
    if (!isPasswordValid) {
      return {
        success: false,
        error: 'Credenciales incorrectas'
      };
    }

    const { passwordHash: _, ...userWithoutPassword } = user;
    
    return {
      success: true,
      user: userWithoutPassword
    };
  } catch (error: any) {
    console.error('Error en loginUser:', error);
    return {
      success: false,
      error: error.message || 'Error al autenticar usuario'
    };
  }
}

export async function getUserById(id: number): Promise<Omit<User, 'passwordHash'> | null> {
  try {
    const db = await getDatabase();
    const user = db.getUserById(id);
    
    if (!user) {
      return null;
    }

    const { passwordHash: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  } catch (error) {
    console.error('Error en getUserById:', error);
    return null;
  }
}

export async function updateUserProfile(
  id: number,
  email: string,
  name: string,
  phone?: string,
  position?: string,
  profilePhoto?: string,
  role?: UserRole,
  department?: string
): Promise<AuthResult> {
  try {
    if (!email || !name) {
      return {
        success: false,
        error: 'Email y nombre son requeridos'
      };
    }

    const db = await getDatabase();
    
    const existingUser = db.getUserById(id);
    if (!existingUser) {
      return {
        success: false,
        error: 'Usuario no encontrado'
      };
    }

    const userWithEmail = db.getUserByEmail(email);
    if (userWithEmail && userWithEmail.id !== id) {
      return {
        success: false,
        error: 'El email ya está en uso por otro usuario'
      };
    }

    const updatedUser = db.updateUserProfile(id, email, name, phone, position, profilePhoto, role, department);
    
    if (!updatedUser) {
      return {
        success: false,
        error: 'Error al actualizar el perfil'
      };
    }

    const { passwordHash: _, ...userWithoutPassword } = updatedUser;
    
    return {
      success: true,
      user: userWithoutPassword
    };
  } catch (error: any) {
    console.error('Error en updateUserProfile:', error);
    return {
      success: false,
      error: error.message || 'Error al actualizar el perfil'
    };
  }
}

