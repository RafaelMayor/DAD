import initSqlJs, { Database as SqlJsDatabase } from 'sql.js';
import * as path from 'path';
import * as fs from 'fs';
import { app } from 'electron';
import * as bcrypt from 'bcryptjs';

export type UserRole = 'Administrador' | 'Gerente' | 'Empleado';

export interface User {
  id: number;
  email: string;
  passwordHash: string;
  name: string;
  phone?: string;
  position?: string;
  profilePhoto?: string;
  role: UserRole;
  department?: string;
  createdAt: string;
}

class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private dbPath: string;
  private SQL: any = null;

  constructor() {
    const userDataPath = app.getPath('userData');
    const dbDir = path.join(userDataPath, 'jhandler-db');
    
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    
    this.dbPath = path.join(dbDir, 'jhandler.db');
  }

  async initialize(): Promise<void> {
    try {
      if (!this.SQL) {
        this.SQL = await initSqlJs({
          locateFile: (file: string) => {
            const distWasmPath = path.join(__dirname, '../sql-wasm.wasm');
            if (fs.existsSync(distWasmPath)) {
              return distWasmPath;
            }
            const nodeModulesWasmPath = path.join(__dirname, '../node_modules/sql.js/dist/sql-wasm.wasm');
            if (fs.existsSync(nodeModulesWasmPath)) {
              return nodeModulesWasmPath;
            }
            console.warn(`No se encontró ${file} localmente, intentando descargar desde internet`);
            return `https://sql.js.org/dist/${file}`;
          }
        });
      }

      if (fs.existsSync(this.dbPath)) {
        try {
          const buffer = fs.readFileSync(this.dbPath);
          this.db = new this.SQL.Database(buffer);
          console.log('Base de datos existente cargada');
        } catch (error) {
          console.warn('Error al cargar base de datos existente, creando nueva:', error);
          this.db = new this.SQL.Database();
        }
      } else {
        this.db = new this.SQL.Database();
        console.log('Nueva base de datos creada');
      }

      this.createTables();
      this.saveDatabase();
      
      await this.initializeDefaultAdmin();
      
      console.log('Base de datos inicializada en:', this.dbPath);
    } catch (error) {
      console.error('Error al inicializar la base de datos:', error);
      throw error;
    }
  }

  private createTables(): void {
    if (!this.db) return;

    this.db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        passwordHash TEXT NOT NULL,
        name TEXT NOT NULL,
        phone TEXT,
        position TEXT,
        profilePhoto TEXT,
        role TEXT NOT NULL DEFAULT 'Empleado',
        department TEXT,
        createdAt TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `);

    try {
      this.db.run('ALTER TABLE users ADD COLUMN phone TEXT');
    } catch (e: any) {
    }
    
    try {
      this.db.run('ALTER TABLE users ADD COLUMN position TEXT');
    } catch (e: any) {
    }
    
    try {
      this.db.run('ALTER TABLE users ADD COLUMN profilePhoto TEXT');
    } catch (e: any) {
    }
    
    try {
      this.db.run("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'Empleado'");
    } catch (e: any) {
    }
    
    try {
      this.db.run('ALTER TABLE users ADD COLUMN department TEXT');
    } catch (e: any) {
    }
    
    try {
      this.db.run("UPDATE users SET role = 'Empleado' WHERE role IS NULL OR role = ''");
    } catch (e: any) {
    }

    this.db.run(`
      CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)
    `);

    this.db.run(`
      CREATE TABLE IF NOT EXISTS absences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employeeId INTEGER NOT NULL,
        type TEXT NOT NULL,
        description TEXT,
        startDate TEXT NOT NULL,
        endDate TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        approvedBy INTEGER,
        rejectionReason TEXT,
        createdAt TEXT NOT NULL DEFAULT (datetime('now')),
        updatedAt TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (employeeId) REFERENCES users(id),
        FOREIGN KEY (approvedBy) REFERENCES users(id)
      )
    `);

    this.db.run(`
      CREATE INDEX IF NOT EXISTS idx_absences_employeeId ON absences(employeeId)
    `);
    this.db.run(`
      CREATE INDEX IF NOT EXISTS idx_absences_status ON absences(status)
    `);
    this.db.run(`
      CREATE INDEX IF NOT EXISTS idx_absences_startDate ON absences(startDate)
    `);

    console.log('Tablas creadas correctamente');
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Error al guardar la base de datos:', error);
    }
  }

  getUserByEmail(email: string): User | null {
    if (!this.db) return null;

    const stmt = this.db.prepare('SELECT * FROM users WHERE email = ?');
    stmt.bind([email]);
    
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      return row as User;
    }
    
    stmt.free();
    return null;
  }

  createUser(email: string, passwordHash: string, name: string, role: UserRole = 'Empleado', department?: string): User | null {
    if (!this.db) return null;

    try {
      const existingUser = this.getUserByEmail(email);
      if (existingUser) {
        throw new Error('El email ya está registrado');
      }

      const stmt = this.db.prepare(
        'INSERT INTO users (email, passwordHash, name, role, department, createdAt) VALUES (?, ?, ?, ?, ?, datetime("now"))'
      );
      stmt.run([email, passwordHash, name, role, department || null]);
      stmt.free();

      const lastIdStmt = this.db.prepare('SELECT last_insert_rowid() as id');
      lastIdStmt.step();
      const result = lastIdStmt.getAsObject();
      lastIdStmt.free();

      this.saveDatabase();
      
      return this.getUserById(result.id as number);
    } catch (error: any) {
      if (error.message === 'El email ya está registrado') {
        throw error;
      }
      console.error('Error al crear usuario:', error);
      throw new Error('Error al crear el usuario');
    }
  }

  private async initializeDefaultAdmin(): Promise<void> {
    if (!this.db) {
      console.error('Base de datos no inicializada, no se puede crear usuario admin');
      return;
    }

    try {
      const adminUser = this.getUserByEmail('admin@talentocorp.com');
      if (adminUser) {
        console.log('Usuario administrador ya existe');
        if (adminUser.role !== 'Administrador') {
          const stmt = this.db.prepare('UPDATE users SET role = ? WHERE email = ?');
          stmt.run(['Administrador', 'admin@talentocorp.com']);
          stmt.free();
          this.saveDatabase();
          console.log('Rol de administrador actualizado');
        }
        if (!adminUser.department || adminUser.department === '') {
          const stmt = this.db.prepare('UPDATE users SET department = ? WHERE email = ?');
          stmt.run(['Administración', 'admin@talentocorp.com']);
          stmt.free();
          this.saveDatabase();
          console.log('Departamento de administrador actualizado');
        }
        return;
      }

      console.log('Creando usuario administrador por defecto...');
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash('12341234', saltRounds);
      console.log('Contraseña hasheada correctamente');

      const stmt = this.db.prepare(
        'INSERT INTO users (email, passwordHash, name, position, role, department, createdAt) VALUES (?, ?, ?, ?, ?, ?, datetime("now"))'
      );
      stmt.run(['admin@talentocorp.com', passwordHash, 'Admin', 'Administrador', 'Administrador', 'Administración']);
      stmt.free();

      this.saveDatabase();
      console.log(' Usuario administrador por defecto creado exitosamente');
      console.log('  Email: admin@talentocorp.com');
      console.log('  Contraseña: 12341234');
    } catch (error: any) {
      console.error('Error al crear usuario administrador por defecto:', error);
      console.error('Detalles del error:', error.message);
      console.error('Stack:', error.stack);
    }
  }

  getUserById(id: number): User | null {
    if (!this.db) return null;

    const stmt = this.db.prepare('SELECT * FROM users WHERE id = ?');
    stmt.bind([id]);
    
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      return row as User;
    }
    
    stmt.free();
    return null;
  }

  updateUserProfile(
    id: number,
    email: string,
    name: string,
    phone?: string,
    position?: string,
    profilePhoto?: string,
    role?: UserRole,
    department?: string
  ): User | null {
    if (!this.db) return null;

    try {
      if (role) {
        const stmt = this.db.prepare(
          'UPDATE users SET email = ?, name = ?, phone = ?, position = ?, profilePhoto = ?, role = ?, department = ? WHERE id = ?'
        );
        stmt.run([email, name, phone || null, position || null, profilePhoto || null, role, department || null, id]);
        stmt.free();
      } else {
        const stmt = this.db.prepare(
          'UPDATE users SET email = ?, name = ?, phone = ?, position = ?, profilePhoto = ?, department = ? WHERE id = ?'
        );
        stmt.run([email, name, phone || null, position || null, profilePhoto || null, department || null, id]);
        stmt.free();
      }

      this.saveDatabase();
      
      return this.getUserById(id);
    } catch (error: any) {
      console.error('Error al actualizar perfil:', error);
      throw error;
    }
  }

  getAllUsers(): User[] {
    if (!this.db) return [];

    const stmt = this.db.prepare('SELECT * FROM users ORDER BY createdAt DESC');
    const users: User[] = [];
    
    while (stmt.step()) {
      users.push(stmt.getAsObject() as User);
    }
    
    stmt.free();
    return users;
  }

  createAbsence(
    employeeId: number,
    type: string,
    description: string,
    startDate: string,
    endDate: string
  ): any {
    if (!this.db) return null;

    try {
      const stmt = this.db.prepare(
        'INSERT INTO absences (employeeId, type, description, startDate, endDate, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, datetime("now"), datetime("now"))'
      );
      stmt.run([employeeId, type, description || null, startDate, endDate, 'pending']);
      stmt.free();

      const lastIdStmt = this.db.prepare('SELECT last_insert_rowid() as id');
      lastIdStmt.step();
      const result = lastIdStmt.getAsObject();
      lastIdStmt.free();

      this.saveDatabase();
      
      return this.getAbsenceById(result.id as number);
    } catch (error: any) {
      console.error('Error al crear ausencia:', error);
      throw error;
    }
  }

  getAbsenceById(id: number): any {
    if (!this.db) return null;

    const stmt = this.db.prepare(`
      SELECT 
        a.*,
        u.name as employeeName,
        u.department as employeeDepartment,
        u.profilePhoto as employeeAvatar,
        approver.name as approverName
      FROM absences a
      LEFT JOIN users u ON a.employeeId = u.id
      LEFT JOIN users approver ON a.approvedBy = approver.id
      WHERE a.id = ?
    `);
    stmt.bind([id]);
    
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      return this.formatAbsence(row);
    }
    
    stmt.free();
    return null;
  }

  getAllAbsences(filters?: {
    employeeId?: number;
    status?: string;
    startDate?: string;
    endDate?: string;
  }): any[] {
    if (!this.db) return [];

    let query = `
      SELECT 
        a.*,
        u.name as employeeName,
        u.department as employeeDepartment,
        u.profilePhoto as employeeAvatar,
        approver.name as approverName
      FROM absences a
      LEFT JOIN users u ON a.employeeId = u.id
      LEFT JOIN users approver ON a.approvedBy = approver.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (filters?.employeeId) {
      query += ' AND a.employeeId = ?';
      params.push(filters.employeeId);
    }

    if (filters?.status) {
      query += ' AND a.status = ?';
      params.push(filters.status);
    }

    if (filters?.startDate) {
      query += ' AND a.startDate >= ?';
      params.push(filters.startDate);
    }

    if (filters?.endDate) {
      query += ' AND a.endDate <= ?';
      params.push(filters.endDate);
    }

    query += ' ORDER BY a.createdAt DESC';

    const stmt = this.db.prepare(query);
    if (params.length > 0) {
      stmt.bind(params);
    }

    const absences: any[] = [];
    while (stmt.step()) {
      absences.push(this.formatAbsence(stmt.getAsObject()));
    }
    
    stmt.free();
    return absences;
  }

  updateAbsenceStatus(
    id: number,
    status: 'approved' | 'rejected' | 'pending',
    approvedBy?: number,
    rejectionReason?: string
  ): any {
    if (!this.db) return null;

    try {
      const stmt = this.db.prepare(
        'UPDATE absences SET status = ?, approvedBy = ?, rejectionReason = ?, updatedAt = datetime("now") WHERE id = ?'
      );
      stmt.run([
        status,
        approvedBy || null,
        rejectionReason || null,
        id
      ]);
      stmt.free();

      this.saveDatabase();
      
      return this.getAbsenceById(id);
    } catch (error: any) {
      console.error('Error al actualizar estado de ausencia:', error);
      throw error;
    }
  }

  deleteAbsence(id: number): boolean {
    if (!this.db) return false;

    try {
      const stmt = this.db.prepare('DELETE FROM absences WHERE id = ?');
      stmt.run([id]);
      stmt.free();

      this.saveDatabase();
      return true;
    } catch (error: any) {
      console.error('Error al eliminar ausencia:', error);
      return false;
    }
  }

  private formatAbsence(row: any): any {
    const start = new Date(row.startDate);
    const end = new Date(row.endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    
    let duration = '';
    if (diffDays === 1) {
      duration = '1 día';
    } else {
      duration = `${diffDays} días`;
    }

    const formatDate = (dateStr: string) => {
      const date = new Date(dateStr);
      return date.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });
    };

    return {
      id: row.id.toString(),
      employee: {
        id: row.employeeId,
        name: row.employeeName || 'Desconocido',
        department: row.employeeDepartment || '',
        avatar: row.employeeAvatar || 'https://c.animaapp.com/NQCQNg3D/img/img-1@2x.png'
      },
      type: row.type,
      description: row.description || '',
      startDate: formatDate(row.startDate),
      endDate: formatDate(row.endDate),
      duration: duration,
      status: row.status,
      approvedBy: row.approverName || row.approvedBy,
      rejectionReason: row.rejectionReason,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt
    };
  }

  close(): void {
    if (this.db) {
      this.saveDatabase();
      this.db.close();
      this.db = null;
    }
  }
}

let dbManager: DatabaseManager | null = null;

export async function getDatabase(): Promise<DatabaseManager> {
  if (!dbManager) {
    dbManager = new DatabaseManager();
    await dbManager.initialize();
  }
  return dbManager;
}

export function closeDatabase(): void {
  if (dbManager) {
    dbManager.close();
    dbManager = null;
  }
}
