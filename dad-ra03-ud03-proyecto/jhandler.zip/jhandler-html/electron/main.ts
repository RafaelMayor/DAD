import { app, BrowserWindow, ipcMain } from 'electron';
import * as path from 'path';
import { getDatabase, closeDatabase } from './database';
import { loginUser, registerUser, getUserById, updateUserProfile } from './auth';

let mainWindow: BrowserWindow | null = null;

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 1000,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    show: false,
    backgroundColor: '#ffffff'
  });

  const isDev = !app.isPackaged;
  
  if (isDev) {
    mainWindow.loadURL('http://localhost:3000').catch((err) => {
      console.error('Error loading URL:', err);
    });
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow?.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(async () => {
  try {
    await getDatabase();
    console.log('Base de datos inicializada');
  } catch (error) {
    console.error('Error al inicializar la base de datos:', error);
  }

  setupAuthHandlers();

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  closeDatabase();
});

function setupAuthHandlers(): void {
  ipcMain.handle('auth:login', async (_event, email: string, password: string) => {
    try {
      return await loginUser(email, password);
    } catch (error: any) {
      console.error('Error en auth:login:', error);
      return {
        success: false,
        error: error.message || 'Error al iniciar sesión'
      };
    }
  });

  ipcMain.handle('auth:signup', async (_event, email: string, password: string, name: string) => {
    try {
      return await registerUser(email, password, name);
    } catch (error: any) {
      console.error('Error en auth:signup:', error);
      return {
        success: false,
        error: error.message || 'Error al registrar usuario'
      };
    }
  });

  ipcMain.handle('auth:getUserById', async (_event, id: number) => {
    try {
      return await getUserById(id);
    } catch (error: any) {
      console.error('Error en auth:getUserById:', error);
      return null;
    }
  });

  ipcMain.handle('auth:updateProfile', async (_event, id: number, email: string, name: string, phone?: string, position?: string, profilePhoto?: string, role?: string, department?: string) => {
    try {
      return await updateUserProfile(id, email, name, phone, position, profilePhoto, role as any, department);
    } catch (error: any) {
      console.error('Error en auth:updateProfile:', error);
      return {
        success: false,
        error: error.message || 'Error al actualizar el perfil'
      };
    }
  });

  ipcMain.handle('employees:create', async (_event, email: string, password: string, name: string, role: string, department?: string, position?: string) => {
    try {
      const { registerUser } = await import('./auth');
      const db = await getDatabase();
      
      const existingUser = db.getUserByEmail(email);
      if (existingUser) {
        return {
          success: false,
          error: 'El email ya está registrado'
        };
      }

      const bcrypt = require('bcryptjs');
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(password, saltRounds);

      const newUser = db.createUser(email, passwordHash, name, role as any, department);
      
      if (!newUser) {
        return {
          success: false,
          error: 'Error al crear el empleado'
        };
      }

      if (position) {
        db.updateUserProfile(newUser.id, newUser.email, newUser.name, undefined, position, undefined, role as any, department);
      }

      const { passwordHash: _, ...userWithoutPassword } = newUser;
      
      return {
        success: true,
        user: userWithoutPassword
      };
    } catch (error: any) {
      console.error('Error en employees:create:', error);
      return {
        success: false,
        error: error.message || 'Error al crear el empleado'
      };
    }
  });

  ipcMain.handle('employees:getAll', async () => {
    try {
      const db = await getDatabase();
      const users = db.getAllUsers();
      
      return users.map(({ passwordHash: _, ...user }) => user);
    } catch (error: any) {
      console.error('Error en employees:getAll:', error);
      return [];
    }
  });

  ipcMain.handle('absences:create', async (_event, employeeId: number, type: string, description: string, startDate: string, endDate: string) => {
    try {
      const db = await getDatabase();
      const absence = db.createAbsence(employeeId, type, description, startDate, endDate);
      
      if (!absence) {
        return {
          success: false,
          error: 'Error al crear la ausencia'
        };
      }

      return {
        success: true,
        absence: absence
      };
    } catch (error: any) {
      console.error('Error en absences:create:', error);
      return {
        success: false,
        error: error.message || 'Error al crear la ausencia'
      };
    }
  });

  ipcMain.handle('absences:getAll', async (_event, filters?: { employeeId?: number; status?: string; startDate?: string; endDate?: string }) => {
    try {
      const db = await getDatabase();
      const absences = db.getAllAbsences(filters);
      return absences;
    } catch (error: any) {
      console.error('Error en absences:getAll:', error);
      return [];
    }
  });

  ipcMain.handle('absences:approve', async (_event, id: number, approvedBy: number) => {
    try {
      const db = await getDatabase();
      const absence = db.updateAbsenceStatus(id, 'approved', approvedBy);
      
      if (!absence) {
        return {
          success: false,
          error: 'Error al aprobar la ausencia'
        };
      }

      return {
        success: true,
        absence: absence
      };
    } catch (error: any) {
      console.error('Error en absences:approve:', error);
      return {
        success: false,
        error: error.message || 'Error al aprobar la ausencia'
      };
    }
  });

  ipcMain.handle('absences:reject', async (_event, id: number, approvedBy: number, rejectionReason: string) => {
    try {
      const db = await getDatabase();
      const absence = db.updateAbsenceStatus(id, 'rejected', approvedBy, rejectionReason);
      
      if (!absence) {
        return {
          success: false,
          error: 'Error al rechazar la ausencia'
        };
      }

      return {
        success: true,
        absence: absence
      };
    } catch (error: any) {
      console.error('Error en absences:reject:', error);
      return {
        success: false,
        error: error.message || 'Error al rechazar la ausencia'
      };
    }
  });

  ipcMain.handle('absences:delete', async (_event, id: number) => {
    try {
      const db = await getDatabase();
      const success = db.deleteAbsence(id);
      
      return {
        success: success
      };
    } catch (error: any) {
      console.error('Error en absences:delete:', error);
      return {
        success: false,
        error: error.message || 'Error al eliminar la ausencia'
      };
    }
  });
}

