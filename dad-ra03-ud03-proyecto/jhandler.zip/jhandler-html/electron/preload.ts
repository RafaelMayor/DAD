import { contextBridge, ipcRenderer } from 'electron';

// Tipos para las funciones de autenticación
export interface AuthAPI {
  login: (email: string, password: string) => Promise<{
    success: boolean;
    user?: { id: number; email: string; name: string; role: string; department?: string; createdAt: string };
    error?: string;
  }>;
  signup: (email: string, password: string, name: string) => Promise<{
    success: boolean;
    user?: { id: number; email: string; name: string; role: string; department?: string; createdAt: string };
    error?: string;
  }>;
  getUserById: (id: number) => Promise<{
    id: number;
    email: string;
    name: string;
    phone?: string;
    position?: string;
    profilePhoto?: string;
    role: string;
    department?: string;
    createdAt: string;
  } | null>;
  updateProfile: (id: number, email: string, name: string, phone?: string, position?: string, profilePhoto?: string, role?: string, department?: string) => Promise<{
    success: boolean;
    user?: { id: number; email: string; name: string; phone?: string; position?: string; profilePhoto?: string; role: string; department?: string; createdAt: string };
    error?: string;
  }>;
}

// Tipos para las funciones de empleados
export interface EmployeesAPI {
  create: (email: string, password: string, name: string, role: string, department?: string, position?: string) => Promise<{
    success: boolean;
    user?: { id: number; email: string; name: string; phone?: string; position?: string; profilePhoto?: string; role: string; department?: string; createdAt: string };
    error?: string;
  }>;
  getAll: () => Promise<Array<{
    id: number;
    email: string;
    name: string;
    phone?: string;
    position?: string;
    profilePhoto?: string;
    role: string;
    department?: string;
    createdAt: string;
  }>>;
}

// Tipos para las funciones de ausencias
export interface AbsencesAPI {
  create: (employeeId: number, type: string, description: string, startDate: string, endDate: string) => Promise<{
    success: boolean;
    absence?: any;
    error?: string;
  }>;
  getAll: (filters?: { employeeId?: number; status?: string; startDate?: string; endDate?: string }) => Promise<any[]>;
  approve: (id: number, approvedBy: number) => Promise<{
    success: boolean;
    absence?: any;
    error?: string;
  }>;
  reject: (id: number, approvedBy: number, rejectionReason: string) => Promise<{
    success: boolean;
    absence?: any;
    error?: string;
  }>;
  delete: (id: number) => Promise<{
    success: boolean;
    error?: string;
  }>;
}

// Exponer APIs seguras al renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  versions: {
    node: process.versions.node,
    chrome: process.versions.chrome,
    electron: process.versions.electron
  },
  auth: {
    login: (email: string, password: string) =>
      ipcRenderer.invoke('auth:login', email, password),
    signup: (email: string, password: string, name: string) =>
      ipcRenderer.invoke('auth:signup', email, password, name),
    getUserById: (id: number) =>
      ipcRenderer.invoke('auth:getUserById', id),
    updateProfile: (id: number, email: string, name: string, phone?: string, position?: string, profilePhoto?: string, role?: string, department?: string) =>
      ipcRenderer.invoke('auth:updateProfile', id, email, name, phone, position, profilePhoto, role, department)
  } as AuthAPI,
  employees: {
    create: (email: string, password: string, name: string, role: string, department?: string, position?: string) =>
      ipcRenderer.invoke('employees:create', email, password, name, role, department, position),
    getAll: () =>
      ipcRenderer.invoke('employees:getAll')
  } as EmployeesAPI,
  absences: {
    create: (employeeId: number, type: string, description: string, startDate: string, endDate: string) =>
      ipcRenderer.invoke('absences:create', employeeId, type, description, startDate, endDate),
    getAll: (filters?: { employeeId?: number; status?: string; startDate?: string; endDate?: string }) =>
      ipcRenderer.invoke('absences:getAll', filters),
    approve: (id: number, approvedBy: number) =>
      ipcRenderer.invoke('absences:approve', id, approvedBy),
    reject: (id: number, approvedBy: number, rejectionReason: string) =>
      ipcRenderer.invoke('absences:reject', id, approvedBy, rejectionReason),
    delete: (id: number) =>
      ipcRenderer.invoke('absences:delete', id)
  } as AbsencesAPI
});

