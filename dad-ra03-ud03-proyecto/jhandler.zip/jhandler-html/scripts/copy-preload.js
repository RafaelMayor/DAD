const fs = require('fs');
const path = require('path');

const preloadPath = path.join(__dirname, '../dist/preload.js');

const distDir = path.join(__dirname, '../dist');
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

if (!fs.existsSync(preloadPath)) {
  console.error(`Error: No se encontró el archivo compilado en ${preloadPath}`);
  console.error('Asegúrate de que TypeScript haya compilado preload.ts primero');
  process.exit(1);
}

console.log('✓ preload.js verificado en dist/');

