const fs = require('fs');
const path = require('path');

const source = path.join(__dirname, '../electron/preload.js');
const dest = path.join(__dirname, '../dist/preload.js');

// Crear directorio dist si no existe
const distDir = path.join(__dirname, '../dist');
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

// Copiar el archivo
try {
  fs.copyFileSync(source, dest);
  console.log('✓ preload.js copiado a dist/');
} catch (error) {
  console.error('Error copiando preload.js:', error);
  process.exit(1);
}

