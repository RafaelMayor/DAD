const fs = require('fs');
const path = require('path');

// Con rootDir configurado en tsconfig.main.json, preload.js se compila directamente a dist/
// Este script solo verifica que el archivo existe
const preloadPath = path.join(__dirname, '../dist/preload.js');

// Crear directorio dist si no existe
const distDir = path.join(__dirname, '../dist');
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

// Verificar que el archivo compilado existe
if (!fs.existsSync(preloadPath)) {
  console.error(`Error: No se encontró el archivo compilado en ${preloadPath}`);
  console.error('Asegúrate de que TypeScript haya compilado preload.ts primero');
  process.exit(1);
}

console.log('✓ preload.js verificado en dist/');

