const fs = require('fs');
const path = require('path');

// Copiar sql-wasm.wasm a dist/ para que esté disponible en producción
const source = path.join(__dirname, '../node_modules/sql.js/dist/sql-wasm.wasm');
const dest = path.join(__dirname, '../dist/sql-wasm.wasm');

// Crear directorio dist si no existe
const distDir = path.join(__dirname, '../dist');
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

// Verificar que el archivo fuente existe
if (!fs.existsSync(source)) {
  console.warn(`Advertencia: No se encontró sql-wasm.wasm en ${source}`);
  console.warn('La aplicación intentará descargarlo desde internet si es necesario');
} else {
  // Copiar el archivo
  try {
    fs.copyFileSync(source, dest);
    console.log('✓ sql-wasm.wasm copiado a dist/');
  } catch (error) {
    console.error('Error copiando sql-wasm.wasm:', error);
  }
}


