const fs = require('fs');
const path = require('path');

const source = path.join(__dirname, '../node_modules/sql.js/dist/sql-wasm.wasm');
const dest = path.join(__dirname, '../dist/sql-wasm.wasm');

const distDir = path.join(__dirname, '../dist');
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

if (!fs.existsSync(source)) {
  console.warn(`Advertencia: No se encontró sql-wasm.wasm en ${source}`);
  console.warn('La aplicación intentará descargarlo desde internet si es necesario');
} else {
  try {
    fs.copyFileSync(source, dest);
    console.log('✓ sql-wasm.wasm copiado a dist/');
  } catch (error) {
    console.error('Error copiando sql-wasm.wasm:', error);
  }
}


