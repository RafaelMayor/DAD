import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { I18nProvider } from './contexts/I18nContext';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Empleados from './pages/Empleados';
import Ausencias from './pages/Ausencias';
import Nominas from './pages/Nominas';
import Informes from './pages/Informes';
import Configuracion from './pages/Configuracion';
import ProtectedRoute from './components/ProtectedRoute';

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <I18nProvider>
        <AuthProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/empleados"
                element={
                  <ProtectedRoute>
                    <Empleados />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/ausencias"
                element={
                  <ProtectedRoute>
                    <Ausencias />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/nominas"
                element={
                  <ProtectedRoute>
                    <Nominas />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/informes"
                element={
                  <ProtectedRoute>
                    <Informes />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/configuracion"
                element={
                  <ProtectedRoute>
                    <Configuracion />
                  </ProtectedRoute>
                }
              />
              <Route path="/" element={<Navigate to="/login" replace />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </I18nProvider>
    </ThemeProvider>
  );
};

export default App;

