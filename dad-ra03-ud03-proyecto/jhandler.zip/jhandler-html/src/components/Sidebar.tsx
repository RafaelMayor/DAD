import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useI18n } from '../contexts/I18nContext';
import './Sidebar.css';

const Sidebar: React.FC = () => {
  const location = useLocation();
  const { user } = useAuth();
  const { t } = useI18n();

  const navItems = [
    { path: '/dashboard', label: t('nav.dashboard'), icon: 'fa-solid fa-chart-line' },
    { path: '/empleados', label: t('nav.employees'), icon: 'fa-solid fa-users' },
    { path: '/ausencias', label: t('nav.absences'), icon: 'fa-solid fa-calendar-days' },
    { path: '/nominas', label: t('nav.payroll'), icon: 'fa-solid fa-file-invoice-dollar' },
    { path: '/informes', label: t('nav.reports'), icon: 'fa-solid fa-chart-bar' },
    { path: '/configuracion', label: t('nav.settings'), icon: 'fa-solid fa-gear' }
  ];

  return (
    <aside className="sidebar" role="navigation" aria-label="Navegación principal">
      <header className="sidebar-header">
        <i
          className="fa-solid fa-users-gear sidebar-logo"
          style={{ color: '#2A9D8F', fontSize: '24px' }}
        ></i>
        <div className="sidebar-company-info">
          <h1 className="sidebar-username">jhandler</h1>
          <p className="sidebar-company-name">TalentoCorp S.L.</p>
        </div>
      </header>
      <nav className="sidebar-nav">
        <ul className="sidebar-nav-list">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <li key={item.path} className={`sidebar-nav-item ${isActive ? 'sidebar-nav-item-active' : ''}`}>
                <Link
                  to={item.path}
                  className={`sidebar-nav-link ${isActive ? 'sidebar-nav-link-active' : ''}`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <i className={`${item.icon} sidebar-nav-icon`}></i>
                  <span className="sidebar-nav-text">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;

