import React from 'react';
import { useAuth } from '../contexts/AuthContext';

interface UserAvatarProps {
  size?: number;
  className?: string;
}

const UserAvatar: React.FC<UserAvatarProps> = ({ size = 42, className = '' }) => {
  const { user } = useAuth();
  
  const defaultImage = 'https://c.animaapp.com/6eePod7j/img/img@2x.png';
  const profilePhoto = user?.profilePhoto || defaultImage;
  
  // Agregar un key basado en el profilePhoto para forzar la actualización cuando cambie
  const imageKey = user?.profilePhoto ? `avatar-${user.id}-${user.profilePhoto.substring(0, 20)}` : 'avatar-default';

  return (
    <img
      key={imageKey}
      className={className || 'user-avatar'}
      src={profilePhoto}
      alt={user?.name || 'Usuario'}
      style={{ width: `${size}px`, height: `${size}px` }}
      onError={(e) => {
        // Si la imagen falla al cargar, usar la imagen por defecto
        const target = e.target as HTMLImageElement;
        if (target.src !== defaultImage) {
          target.src = defaultImage;
        }
      }}
    />
  );
};

export default UserAvatar;

