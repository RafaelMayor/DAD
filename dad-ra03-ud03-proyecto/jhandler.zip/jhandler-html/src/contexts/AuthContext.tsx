import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'Administrador' | 'Gerente' | 'Empleado';

interface User {
  id: number;
  name: string;
  email: string;
  phone?: string;
  position?: string;
  profilePhoto?: string;
  role: UserRole;
  department?: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  signup: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  updateUser: (userData: User) => void;
  isAuthenticated: boolean;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadSavedUser = async () => {
      try {
        const savedUser = localStorage.getItem('user');
        if (savedUser) {
          const userData = JSON.parse(savedUser);
          if (window.electronAPI?.auth && userData.id) {
            const dbUser = await window.electronAPI.auth.getUserById(userData.id);
            if (dbUser) {
              setUser(dbUser);
              localStorage.setItem('user', JSON.stringify(dbUser));
            } else {
              localStorage.removeItem('user');
            }
          } else {
            setUser(userData);
          }
        }
      } catch (error) {
        console.error('Error al cargar usuario guardado:', error);
        localStorage.removeItem('user');
      } finally {
        setLoading(false);
      }
    };

    loadSavedUser();
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      if (!window.electronAPI?.auth) {
        return {
          success: false,
          error: 'La aplicación no está ejecutándose en Electron'
        };
      }

      const result = await window.electronAPI.auth.login(email, password);
      
      if (result.success && result.user) {
        setUser(result.user);
        localStorage.setItem('user', JSON.stringify(result.user));
        return { success: true };
      } else {
        return {
          success: false,
          error: result.error || 'Error al iniciar sesión'
        };
      }
    } catch (error: any) {
      console.error('Error en login:', error);
      return {
        success: false,
        error: error.message || 'Error al iniciar sesión'
      };
    }
  };

  const signup = async (email: string, password: string, name: string): Promise<{ success: boolean; error?: string }> => {
    try {
      if (!window.electronAPI?.auth) {
        return {
          success: false,
          error: 'La aplicación no está ejecutándose en Electron'
        };
      }

      const result = await window.electronAPI.auth.signup(email, password, name);
      
      if (result.success && result.user) {
        setUser(result.user);
        localStorage.setItem('user', JSON.stringify(result.user));
        return { success: true };
      } else {
        return {
          success: false,
          error: result.error || 'Error al crear la cuenta'
        };
      }
    } catch (error: any) {
      console.error('Error en signup:', error);
      return {
        success: false,
        error: error.message || 'Error al crear la cuenta'
      };
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateUser = (userData: User) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        signup,
        updateUser,
        isAuthenticated: !!user,
        loading
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

