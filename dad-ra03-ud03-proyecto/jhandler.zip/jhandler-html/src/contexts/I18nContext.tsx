import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'es' | 'en';

interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

const translations: Translations = {
  es: {
    'nav.dashboard': 'Dashboard',
    'nav.employees': 'Empleados',
    'nav.absences': 'Ausencias',
    'nav.payroll': 'Nóminas',
    'nav.reports': 'Informes',
    'nav.settings': 'Configuración',
    
    'dashboard.title': 'Dashboard',
    'dashboard.subtitle': 'Resumen general de recursos humanos',
    'dashboard.activeEmployees': 'Empleados Activos',
    'dashboard.absencesToday': 'Ausencias Hoy',
    'dashboard.pendingRequests': 'Solicitudes Pendientes',
    'dashboard.birthdays': 'Cumpleaños',
    'dashboard.quickActions': 'Acciones Rápidas',
    'dashboard.addEmployee': 'Añadir Empleado',
    'dashboard.generateReport': 'Generar Informe',
    'dashboard.manageAbsences': 'Gestionar Ausencias',
    'dashboard.requestAbsence': 'Enviar Solicitud de Ausencia',
    'dashboard.viewMyPayroll': 'Ver Mi Nómina',
    'dashboard.viewMyReports': 'Ver Mis Informes',
    
    'settings.title': 'Configuración',
    'settings.subtitle': 'Gestiona las preferencias y configuraciones de la aplicación',
    'settings.profile': 'Perfil',
    'settings.preferences': 'Preferencias',
    'settings.accessibility': 'Accesibilidad',
    'settings.roles': 'Roles y Permisos',
    
    'preferences.title': 'Preferencias',
    'preferences.description': 'Configura tus preferencias de la aplicación',
    'preferences.theme': 'Tema',
    'preferences.theme.light': 'Claro',
    'preferences.theme.dark': 'Oscuro',
    'preferences.language': 'Idioma',
    'preferences.language.spanish': 'Español',
    'preferences.language.english': 'Inglés',
    
    'accessibility.title': 'Accesibilidad',
    'accessibility.description': 'Ajusta la accesibilidad de la aplicación',
    'accessibility.fontSize': 'Tamaño de fuente',
    'accessibility.fontSize.small': 'Pequeño',
    'accessibility.fontSize.medium': 'Medio',
    'accessibility.fontSize.large': 'Grande',
    'accessibility.highContrast': 'Alto contraste',
    'accessibility.reduceMotion': 'Reducir animaciones',
    'accessibility.screenReader': 'Modo lector de pantalla',
    'accessibility.focusVisible': 'Resaltar elementos enfocados',
    
    'profile.title': 'Información de Perfil',
    'profile.name': 'Nombre completo',
    'profile.email': 'Correo electrónico',
    'profile.phone': 'Teléfono',
    'profile.position': 'Cargo',
    'profile.department': 'Departamento',
    'profile.reset': 'Restablecer',
    'profile.save': 'Guardar cambios',
    'profile.saving': 'Guardando...',
    'profile.logout': 'Cerrar sesión',
  },
  en: {
    'nav.dashboard': 'Dashboard',
    'nav.employees': 'Employees',
    'nav.absences': 'Absences',
    'nav.payroll': 'Payroll',
    'nav.reports': 'Reports',
    'nav.settings': 'Settings',
    
    'dashboard.title': 'Dashboard',
    'dashboard.subtitle': 'Human resources overview',
    'dashboard.activeEmployees': 'Active Employees',
    'dashboard.absencesToday': 'Absences Today',
    'dashboard.pendingRequests': 'Pending Requests',
    'dashboard.birthdays': 'Birthdays',
    'dashboard.quickActions': 'Quick Actions',
    'dashboard.addEmployee': 'Add Employee',
    'dashboard.generateReport': 'Generate Report',
    'dashboard.manageAbsences': 'Manage Absences',
    'dashboard.requestAbsence': 'Request Absence',
    'dashboard.viewMyPayroll': 'View My Payroll',
    'dashboard.viewMyReports': 'View My Reports',
    
    'settings.title': 'Settings',
    'settings.subtitle': 'Manage application preferences and settings',
    'settings.profile': 'Profile',
    'settings.preferences': 'Preferences',
    'settings.accessibility': 'Accessibility',
    'settings.roles': 'Roles and Permissions',
    'profile.title': 'Profile Information',
    'profile.name': 'Full Name',
    'profile.email': 'Email',
    'profile.phone': 'Phone',
    'profile.position': 'Position',
    'profile.reset': 'Reset',
    'profile.save': 'Save Changes',
    'profile.saving': 'Saving...',
    'profile.logout': 'Log Out',
    
    'preferences.title': 'Preferences',
    'preferences.description': 'Configure your application preferences',
    'preferences.theme': 'Theme',
    'preferences.theme.light': 'Light',
    'preferences.theme.dark': 'Dark',
    'preferences.language': 'Language',
    'preferences.language.spanish': 'Spanish',
    'preferences.language.english': 'English',
    
    'accessibility.title': 'Accessibility',
    'accessibility.description': 'Adjust application accessibility',
    'accessibility.fontSize': 'Font Size',
    'accessibility.fontSize.small': 'Small',
    'accessibility.fontSize.medium': 'Medium',
    'accessibility.fontSize.large': 'Large',
    'accessibility.highContrast': 'High Contrast',
    'accessibility.reduceMotion': 'Reduce Motion',
    'accessibility.screenReader': 'Screen Reader Mode',
    'accessibility.focusVisible': 'Highlight Focused Elements',
  }
};

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLang = localStorage.getItem('language') as Language;
    return savedLang || 'es';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
    document.documentElement.setAttribute('lang', language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    return translations[language]?.[key] || key;
  };

  return (
    <I18nContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = () => {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
};

