import { useAuth, UserRole } from '../contexts/AuthContext';

interface Permissions {
  canManageUsers: boolean;
  canCreateUsers: boolean;
  canEditUsers: boolean;
  canDeleteUsers: boolean;
  canManageAdminUsers: boolean;
  canManageNominas: boolean;
  canManageInformes: boolean;
  canApproveAbsences: boolean;
  canManageAbsences: boolean;
  canViewOwnDataOnly: boolean;
}

export const usePermissions = (): Permissions => {
  const { user } = useAuth();
  const role = user?.role || 'Empleado';

  const permissions: Permissions = {
    canManageUsers: role === 'Administrador' || role === 'Gerente',
    canCreateUsers: role === 'Administrador' || role === 'Gerente',
    canEditUsers: role === 'Administrador' || role === 'Gerente',
    canDeleteUsers: role === 'Administrador' || role === 'Gerente',
    canManageAdminUsers: role === 'Administrador',
    
    canManageNominas: role === 'Administrador' || role === 'Gerente',
    
    canManageInformes: role === 'Administrador' || role === 'Gerente',
    
    canApproveAbsences: role === 'Administrador' || role === 'Gerente',
    canManageAbsences: role === 'Administrador' || role === 'Gerente',
    
    canViewOwnDataOnly: role === 'Empleado'
  };

  return permissions;
};

export const canManageUserRole = (currentUserRole: UserRole, targetUserRole: UserRole): boolean => {
  if (currentUserRole === 'Administrador') {
    return true;
  }
  
  if (currentUserRole === 'Gerente') {
    return targetUserRole === 'Empleado' || targetUserRole === 'Gerente';
  }
  
  return false;
};

