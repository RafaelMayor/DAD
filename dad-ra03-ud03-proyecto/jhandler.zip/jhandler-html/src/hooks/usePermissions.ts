import { useAuth, UserRole } from '../contexts/AuthContext';

interface Permissions {
  canManageUsers: boolean;
  canCreateUsers: boolean;
  canEditUsers: boolean;
  canDeleteUsers: boolean;
  canManageAdminUsers: boolean;
  canManageNominas: boolean;
  canManageInformes: boolean;
  canApproveAbsences: boolean;
  canManageAbsences: boolean;
  canViewOwnDataOnly: boolean;
}

export const usePermissions = (): Permissions => {
  const { user } = useAuth();
  const role = user?.role || 'Empleado';

  const permissions: Permissions = {
    // Gestión de usuarios
    canManageUsers: role === 'Administrador' || role === 'Gerente',
    canCreateUsers: role === 'Administrador' || role === 'Gerente',
    canEditUsers: role === 'Administrador' || role === 'Gerente',
    canDeleteUsers: role === 'Administrador' || role === 'Gerente',
    canManageAdminUsers: role === 'Administrador', // Solo admin puede gestionar otros admins
    
    // Gestión de nóminas
    canManageNominas: role === 'Administrador' || role === 'Gerente',
    
    // Gestión de informes
    canManageInformes: role === 'Administrador' || role === 'Gerente',
    
    // Gestión de ausencias
    canApproveAbsences: role === 'Administrador' || role === 'Gerente',
    canManageAbsences: role === 'Administrador' || role === 'Gerente',
    
    // Vista limitada (solo datos propios)
    canViewOwnDataOnly: role === 'Empleado'
  };

  return permissions;
};

export const canManageUserRole = (currentUserRole: UserRole, targetUserRole: UserRole): boolean => {
  // Administrador puede gestionar todos los roles
  if (currentUserRole === 'Administrador') {
    return true;
  }
  
  // Gerente puede gestionar Empleado y Gerente, pero no Administrador
  if (currentUserRole === 'Gerente') {
    return targetUserRole === 'Empleado' || targetUserRole === 'Gerente';
  }
  
  // Empleado no puede gestionar ningún usuario
  return false;
};

