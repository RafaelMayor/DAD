import React, { useState } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import './Ausencias.css';

interface Absence {
  id: string;
  employee: {
    name: string;
    department: string;
    avatar: string;
  };
  type: string;
  description: string;
  startDate: string;
  endDate: string;
  duration: string;
  status: 'approved' | 'pending' | 'rejected';
  approvedBy?: string;
  rejectionReason?: string;
}

const Ausencias: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const [absences] = useState<Absence[]>([
    {
      id: '1',
      employee: {
        name: 'María García López',
        department: 'RRHH',
        avatar: 'https://c.animaapp.com/NQCQNg3D/img/img-1@2x.png'
      },
      type: 'Vacaciones',
      description: 'Descanso familiar',
      startDate: '21/11/2025',
      endDate: '28/11/2025',
      duration: '8 días',
      status: 'approved',
      approvedBy: 'Admin'
    },
    {
      id: '2',
      employee: {
        name: 'Carlos Rodríguez Sánchez',
        department: 'Desarrollador',
        avatar: 'https://c.animaapp.com/NQCQNg3D/img/img-2@2x.png'
      },
      type: 'Enfermedad',
      description: 'Gripe común',
      startDate: '1/11/2025',
      endDate: '3/11/2025',
      duration: '3 días',
      status: 'pending'
    },
    {
      id: '3',
      employee: {
        name: 'Ana Martínez Torres',
        department: 'Marketing',
        avatar: 'https://c.animaapp.com/NQCQNg3D/img/img-3@2x.png'
      },
      type: 'Personal',
      description: 'Asunto familiar',
      startDate: '22/10/2025',
      endDate: '22/10/2025',
      duration: '1 día',
      status: 'rejected',
      rejectionReason: 'Sin justificación'
    },
    {
      id: '4',
      employee: {
        name: 'David López Fernández',
        department: 'Ventas',
        avatar: 'https://c.animaapp.com/NQCQNg3D/img/img-4@2x.png'
      },
      type: 'Formación',
      description: 'Curso certificación',
      startDate: '15/10/2025',
      endDate: '16/10/2025',
      duration: '2 días',
      status: 'approved',
      approvedBy: 'Admin'
    },
    {
      id: '5',
      employee: {
        name: 'Laura Jiménez Ruiz',
        department: 'Finanzas',
        avatar: 'https://c.animaapp.com/NQCQNg3D/img/img-5@2x.png'
      },
      type: 'Maternidad',
      description: 'Cita médica',
      startDate: '20/09/2025',
      endDate: '20/09/2025',
      duration: '4 horas',
      status: 'approved',
      approvedBy: 'Admin'
    },
    {
      id: '6',
      employee: {
        name: 'Miguel Hernández Vega',
        department: 'Arquitecto Software',
        avatar: 'https://c.animaapp.com/NQCQNg3D/img/img-6@2x.png'
      },
      type: 'Enfermedad',
      description: 'Gripe común',
      startDate: '15/09/2025',
      endDate: '17/09/2025',
      duration: '3 días',
      status: 'rejected',
      rejectionReason: 'Mentiroso'
    }
  ]);

  const handleApprove = (id: string) => {
    console.log('Aprobar ausencia:', id);
    // Aquí iría la lógica para aprobar
  };

  const handleReject = (id: string) => {
    console.log('Rechazar ausencia:', id);
    // Aquí iría la lógica para rechazar
  };

  const filteredAbsences = absences.filter((absence) => {
    const matchesSearch =
      absence.employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      absence.type.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <Layout>
      <div className="ausencias-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Ausencias</h1>
            <p className="page-subtitle">Gestión de ausencias</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <img
                className="user-avatar"
                src="https://c.animaapp.com/NQCQNg3D/img/img@2x.png"
                alt={user?.name || 'Usuario'}
              />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">Gestión de ausencias</h2>
            <div className="section-actions">
              <button className="btn btn-primary">
                <svg className="btn-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path
                    d="M8 3.33334V12.6667M3.33333 8H12.6667"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span className="btn-text">Registrar Ausencia</span>
              </button>
              <button className="btn btn-secondary">
                <img
                  className="btn-icon"
                  src="https://c.animaapp.com/NQCQNg3D/img/vector-11.svg"
                  alt=""
                />
                <span className="btn-text">Exportar</span>
              </button>
            </div>
          </div>
          <div className="filters-section">
            <div className="search-container">
              <svg className="search-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path
                  d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z"
                  stroke="#6B7280"
                  strokeWidth="1.66667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <input
                type="search"
                className="search-input"
                placeholder="Buscar empleado por nombre, email o ID..."
                aria-label="Buscar empleado"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="filter-controls">
              <div className="filter-group">
                <label htmlFor="employee-filter" className="filter-label">
                  Todos los empleados
                </label>
                <select id="employee-filter" className="filter-select">
                  <option value="all">Todos los empleados</option>
                </select>
              </div>
              <div className="filter-group">
                <label htmlFor="start-date" className="filter-label">
                  Fecha Inicio
                </label>
                <input
                  type="date"
                  id="start-date"
                  className="filter-input date-input"
                  aria-label="Fecha de inicio"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div className="filter-group">
                <label htmlFor="end-date" className="filter-label">
                  Fecha Fin
                </label>
                <input
                  type="date"
                  id="end-date"
                  className="filter-input date-input"
                  aria-label="Fecha de fin"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
              <button className="btn btn-filter">
                <span className="btn-text">Filtrar</span>
              </button>
            </div>
          </div>
          <div className="absences-list-section">
            <div className="list-header">
              <h3 className="list-title">Lista de ausencias</h3>
              <p className="list-count">{filteredAbsences.length} ausencias encontradas</p>
            </div>
            <div className="absences-list">
              <div className="list-header-row">
                <div className="header-cell header-employee">Empleado</div>
                <div className="header-cell header-type">Tipo</div>
                <div className="header-cell header-dates">Fechas</div>
                <div className="header-cell header-duration">Duración</div>
                <div className="header-cell header-status">Estado</div>
                <div className="header-cell header-actions"></div>
              </div>
              {filteredAbsences.map((absence) => (
                <article key={absence.id} className="absence-item">
                  <div className="employee-info">
                    <img
                      className="employee-avatar"
                      src={absence.employee.avatar}
                      alt={absence.employee.name}
                    />
                    <div className="employee-details">
                      <h4 className="employee-name">{absence.employee.name}</h4>
                      <p className="employee-department">{absence.employee.department}</p>
                    </div>
                  </div>
                  <div className="absence-type">
                    <p className="type-name">{absence.type}</p>
                    <p className="type-description">{absence.description}</p>
                  </div>
                  <div className="absence-dates">
                    <div className="date-group">
                      <p className="date-value">{absence.startDate}</p>
                      <p className="date-label">Fecha inicio</p>
                    </div>
                    <div className="date-group">
                      <p className="date-value">{absence.endDate}</p>
                      <p className="date-label">Fecha fin</p>
                    </div>
                  </div>
                  <div className="absence-duration">
                    <p className="duration-value">{absence.duration}</p>
                    <p className="duration-label">Duración</p>
                  </div>
                  <div className="absence-status">
                    {absence.status === 'approved' && (
                      <>
                        <span className="status-badge status-approved">Aprobada</span>
                        <p className="status-info">Aprobada por {absence.approvedBy}</p>
                        <img
                          className="status-icon"
                          src="https://c.animaapp.com/NQCQNg3D/img/vector-18.svg"
                          alt=""
                        />
                      </>
                    )}
                    {absence.status === 'pending' && (
                      <div className="status-actions">
                        <span className="status-badge status-pending">Pendiente</span>
                        <button
                          className="btn btn-approve"
                          onClick={() => handleApprove(absence.id)}
                        >
                          Aprobar
                        </button>
                        <button
                          className="btn btn-reject"
                          onClick={() => handleReject(absence.id)}
                        >
                          Rechazar
                        </button>
                      </div>
                    )}
                    {absence.status === 'rejected' && (
                      <>
                        <span className="status-badge status-rejected">Rechazada</span>
                        <p className="status-info">{absence.rejectionReason}</p>
                        <img
                          className="status-icon"
                          src="https://c.animaapp.com/NQCQNg3D/img/vector-18.svg"
                          alt=""
                        />
                      </>
                    )}
                  </div>
                  <div className="absence-actions">
                    <button className="action-button" aria-label="Más opciones">
                      <img
                        className="action-icon"
                        src="https://c.animaapp.com/NQCQNg3D/img/vector.svg"
                        alt=""
                      />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
          <nav className="pagination" aria-label="Paginación">
            <button className="pagination-button pagination-prev">
              <img
                className="pagination-icon"
                src="https://c.animaapp.com/NQCQNg3D/img/vector-12.svg"
                alt=""
              />
              <span className="pagination-text">Anterior</span>
            </button>
            <div className="pagination-numbers">
              <button className="pagination-number pagination-number-active" aria-current="page">
                1
              </button>
              <button className="pagination-number">2</button>
              <button className="pagination-number">3</button>
            </div>
            <button className="pagination-button pagination-next">
              <span className="pagination-text">Siguiente</span>
              <img
                className="pagination-icon"
                src="https://c.animaapp.com/NQCQNg3D/img/vector-13.svg"
                alt=""
              />
            </button>
          </nav>
        </section>
      </div>
    </Layout>
  );
};

export default Ausencias;

