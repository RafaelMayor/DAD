import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import UserAvatar from '../components/UserAvatar';
import { usePermissions } from '../hooks/usePermissions';
import './Ausencias.css';

interface Absence {
  id: string;
  employee: {
    id: number;
    name: string;
    department: string;
    avatar: string;
  };
  type: string;
  description: string;
  startDate: string;
  endDate: string;
  duration: string;
  status: 'approved' | 'pending' | 'rejected';
  approvedBy?: string;
  rejectionReason?: string;
}

const Ausencias: React.FC = () => {
  const { user } = useAuth();
  const permissions = usePermissions();
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [absences, setAbsences] = useState<Absence[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<number | null>(null);
  const [absenceType, setAbsenceType] = useState('');
  const [absenceDescription, setAbsenceDescription] = useState('');
  const [modalStartDate, setModalStartDate] = useState('');
  const [modalEndDate, setModalEndDate] = useState('');
  const [employees, setEmployees] = useState<any[]>([]);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [selectedEmployeeFilter, setSelectedEmployeeFilter] = useState<string>('all');

  useEffect(() => {
    loadEmployees();
    
    if (!permissions.canManageAbsences && user?.id) {
      setSelectedEmployee(user.id);
    }
  }, []);

  useEffect(() => {
    loadAbsences();
  }, [selectedEmployeeFilter, startDate, endDate, user?.id, permissions.canManageAbsences]);

  const loadAbsences = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const filters: any = {};
      if (startDate) filters.startDate = startDate;
      if (endDate) filters.endDate = endDate;
      
      if (!permissions.canManageAbsences && user?.id) {
        filters.employeeId = user.id;
      } else if (selectedEmployeeFilter !== 'all') {
        filters.employeeId = parseInt(selectedEmployeeFilter);
      }
      
      const absencesData = await window.electronAPI?.absences.getAll(filters);
      if (absencesData) {
        setAbsences(absencesData);
      }
    } catch (err: any) {
      console.error('Error al cargar ausencias:', err);
      setError('Error al cargar las ausencias');
    } finally {
      setLoading(false);
    }
  };

  const loadEmployees = async () => {
    try {
      const employeesData = await window.electronAPI?.employees.getAll();
      if (employeesData) {
        setEmployees(employeesData);
      }
    } catch (err) {
      console.error('Error al cargar empleados:', err);
    }
  };

  const handleFilter = () => {
    loadAbsences();
  };

  const handleApprove = async (id: string) => {
    if (!user?.id) return;
    
    try {
      const result = await window.electronAPI?.absences.approve(parseInt(id), user.id);
      if (result?.success) {
        await loadAbsences();
      } else {
        alert(result?.error || 'Error al aprobar la ausencia');
      }
    } catch (err: any) {
      console.error('Error al aprobar ausencia:', err);
      alert('Error al aprobar la ausencia');
    }
  };

  const handleReject = async (id: string) => {
    if (!user?.id) return;
    
    if (!rejectReason.trim()) {
      alert('Por favor, ingresa una razón para el rechazo');
      return;
    }
    
    try {
      const result = await window.electronAPI?.absences.reject(parseInt(id), user.id, rejectReason);
      if (result?.success) {
        setRejectReason('');
        setRejectingId(null);
        await loadAbsences();
      } else {
        alert(result?.error || 'Error al rechazar la ausencia');
      }
    } catch (err: any) {
      console.error('Error al rechazar ausencia:', err);
      alert('Error al rechazar la ausencia');
    }
  };

  const handleCreateAbsence = async () => {
    if (!selectedEmployee || !absenceType || !modalStartDate || !modalEndDate) {
      alert('Por favor, completa todos los campos requeridos');
      return;
    }

    try {
      const result = await window.electronAPI?.absences.create(
        selectedEmployee,
        absenceType,
        absenceDescription,
        modalStartDate,
        modalEndDate
      );
      
      if (result?.success) {
        setShowModal(false);
        setSelectedEmployee(null);
        setAbsenceType('');
        setAbsenceDescription('');
        setModalStartDate('');
        setModalEndDate('');
        await loadAbsences();
      } else {
        alert(result?.error || 'Error al crear la ausencia');
      }
    } catch (err: any) {
      console.error('Error al crear ausencia:', err);
      alert('Error al crear la ausencia');
    }
  };

  const filteredAbsences = absences.filter((absence) => {
    const matchesSearch =
      absence.employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      absence.type.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDateRange = (!startDate || absence.startDate >= startDate) &&
                            (!endDate || absence.endDate <= endDate);
    
    return matchesSearch && matchesDateRange;
  });

  return (
    <Layout>
      <div className="ausencias-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Ausencias</h1>
            <p className="page-subtitle">Gestión de ausencias</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <UserAvatar size={42} className="user-avatar" />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">Gestión de ausencias</h2>
            <div className="section-actions">
              <button 
                className="btn btn-primary"
                onClick={() => setShowModal(true)}
              >
                <svg className="btn-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path
                    d="M8 3.33334V12.6667M3.33333 8H12.6667"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span className="btn-text">
                  {permissions.canManageAbsences ? 'Registrar Ausencia' : 'Enviar Solicitud de Ausencia'}
                </span>
              </button>
              <button className="btn btn-secondary">
                <img
                  className="btn-icon"
                  src="https://c.animaapp.com/NQCQNg3D/img/vector-11.svg"
                  alt=""
                />
                <span className="btn-text">Exportar</span>
              </button>
            </div>
          </div>
          <div className="filters-section">
            <div className="search-container">
              <svg className="search-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path
                  d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z"
                  stroke="#6B7280"
                  strokeWidth="1.66667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <input
                type="search"
                className="search-input"
                placeholder="Buscar empleado por nombre, email o ID..."
                aria-label="Buscar empleado"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="filter-controls">
              {permissions.canManageAbsences && (
                <div className="filter-group">
                  <label htmlFor="employee-filter" className="filter-label">
                    Empleado
                  </label>
                  <select 
                    id="employee-filter" 
                    className="filter-select"
                    value={selectedEmployeeFilter}
                    onChange={(e) => setSelectedEmployeeFilter(e.target.value)}
                  >
                    <option value="all">Todos los empleados</option>
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              <div className="filter-group">
                <label htmlFor="start-date" className="filter-label">
                  Fecha Inicio
                </label>
                <input
                  type="date"
                  id="start-date"
                  className="filter-input date-input"
                  aria-label="Fecha de inicio"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div className="filter-group">
                <label htmlFor="end-date" className="filter-label">
                  Fecha Fin
                </label>
                <input
                  type="date"
                  id="end-date"
                  className="filter-input date-input"
                  aria-label="Fecha de fin"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
              <button className="btn btn-filter" onClick={handleFilter}>
                <span className="btn-text">Filtrar</span>
              </button>
            </div>
          </div>
          <div className="absences-list-section">
            <div className="list-header">
              <h3 className="list-title">Lista de ausencias</h3>
              <p className="list-count">{filteredAbsences.length} ausencias encontradas</p>
            </div>
            <div className="absences-list">
              <div className="list-header-row">
                <div className="header-cell header-employee">Empleado</div>
                <div className="header-cell header-type">Tipo</div>
                <div className="header-cell header-dates">Fechas</div>
                <div className="header-cell header-duration">Duración</div>
                <div className="header-cell header-status">Estado</div>
                <div className="header-cell header-actions"></div>
              </div>
              {filteredAbsences.map((absence) => (
                <article key={absence.id} className="absence-item">
                  <div className="employee-info">
                    <img
                      className="employee-avatar"
                      src={absence.employee.avatar}
                      alt={absence.employee.name}
                    />
                    <div className="employee-details">
                      <h4 className="employee-name">{absence.employee.name}</h4>
                      <p className="employee-department">{absence.employee.department}</p>
                    </div>
                  </div>
                  <div className="absence-type">
                    <p className="type-name">{absence.type}</p>
                    <p className="type-description">{absence.description}</p>
                  </div>
                  <div className="absence-dates">
                    <div className="date-group">
                      <p className="date-value">{absence.startDate}</p>
                      <p className="date-label">Fecha inicio</p>
                    </div>
                    <div className="date-group">
                      <p className="date-value">{absence.endDate}</p>
                      <p className="date-label">Fecha fin</p>
                    </div>
                  </div>
                  <div className="absence-duration">
                    <p className="duration-value">{absence.duration}</p>
                    <p className="duration-label">Duración</p>
                  </div>
                  <div className="absence-status">
                    {absence.status === 'approved' && (
                      <>
                        <span className="status-badge status-approved">Aprobada</span>
                        <p className="status-info">Aprobada por {absence.approvedBy}</p>
                        <img
                          className="status-icon"
                          src="https://c.animaapp.com/NQCQNg3D/img/vector-18.svg"
                          alt=""
                        />
                      </>
                    )}
                    {absence.status === 'pending' && (
                      <div className="status-actions">
                        <span className="status-badge status-pending">Pendiente</span>
                        {permissions.canManageAbsences && (
                          <>
                            <button
                              className="btn btn-approve"
                              onClick={() => handleApprove(absence.id)}
                            >
                              Aprobar
                            </button>
                            <button
                              className="btn btn-reject"
                              onClick={() => setRejectingId(absence.id)}
                            >
                              Rechazar
                            </button>
                          </>
                        )}
                      </div>
                    )}
                    {absence.status === 'rejected' && (
                      <>
                        <span className="status-badge status-rejected">Rechazada</span>
                        <p className="status-info">{absence.rejectionReason}</p>
                        <img
                          className="status-icon"
                          src="https://c.animaapp.com/NQCQNg3D/img/vector-18.svg"
                          alt=""
                        />
                      </>
                    )}
                  </div>
                  <div className="absence-actions">
                    <button className="action-button" aria-label="Más opciones">
                      <img
                        className="action-icon"
                        src="https://c.animaapp.com/NQCQNg3D/img/vector.svg"
                        alt=""
                      />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
          <nav className="pagination" aria-label="Paginación">
            <button className="pagination-button pagination-prev">
              <img
                className="pagination-icon"
                src="https://c.animaapp.com/NQCQNg3D/img/vector-12.svg"
                alt=""
              />
              <span className="pagination-text">Anterior</span>
            </button>
            <div className="pagination-numbers">
              <button className="pagination-number pagination-number-active" aria-current="page">
                1
              </button>
              <button className="pagination-number">2</button>
              <button className="pagination-number">3</button>
            </div>
            <button className="pagination-button pagination-next">
              <span className="pagination-text">Siguiente</span>
              <img
                className="pagination-icon"
                src="https://c.animaapp.com/NQCQNg3D/img/vector-13.svg"
                alt=""
              />
            </button>
          </nav>
        </section>

        {showModal && (
          <div className="modal-overlay" onClick={() => setShowModal(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2 className="modal-title">Registrar Nueva Ausencia</h2>
                <button className="modal-close" onClick={() => setShowModal(false)}>×</button>
              </div>
              <div className="modal-body">
                <div className="form-group">
                  <label htmlFor="employee-select" className="form-label">
                    Empleado {permissions.canManageAbsences ? '' : '(Tú)'}
                  </label>
                  <select
                    id="employee-select"
                    className="form-input"
                    value={selectedEmployee || (permissions.canManageAbsences ? '' : user?.id || '')}
                    onChange={(e) => setSelectedEmployee(parseInt(e.target.value))}
                    disabled={!permissions.canManageAbsences}
                  >
                    <option value="">Seleccionar empleado</option>
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.name} {emp.department ? `- ${emp.department}` : ''}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label htmlFor="type-select" className="form-label">Tipo de Ausencia *</label>
                  <select
                    id="type-select"
                    className="form-input"
                    value={absenceType}
                    onChange={(e) => setAbsenceType(e.target.value)}
                  >
                    <option value="">Seleccionar tipo</option>
                    <option value="Vacaciones">Vacaciones</option>
                    <option value="Enfermedad">Enfermedad</option>
                    <option value="Personal">Personal</option>
                    <option value="Formación">Formación</option>
                    <option value="Maternidad">Maternidad</option>
                    <option value="Paternidad">Paternidad</option>
                    <option value="Otro">Otro</option>
                  </select>
                </div>
                <div className="form-group">
                  <label htmlFor="description" className="form-label">Descripción</label>
                  <textarea
                    id="description"
                    className="form-input"
                    rows={3}
                    value={absenceDescription}
                    onChange={(e) => setAbsenceDescription(e.target.value)}
                    placeholder="Descripción de la ausencia..."
                  />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="modal-start-date" className="form-label">Fecha Inicio *</label>
                    <input
                      type="date"
                      id="modal-start-date"
                      className="form-input"
                      value={modalStartDate}
                      onChange={(e) => setModalStartDate(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="modal-end-date" className="form-label">Fecha Fin *</label>
                    <input
                      type="date"
                      id="modal-end-date"
                      className="form-input"
                      value={modalEndDate}
                      onChange={(e) => setModalEndDate(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancelar
                </button>
                <button className="btn btn-primary" onClick={handleCreateAbsence}>
                  Registrar
                </button>
              </div>
            </div>
          </div>
        )}

        {rejectingId && (
          <div className="modal-overlay" onClick={() => { setRejectingId(null); setRejectReason(''); }}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2 className="modal-title">Rechazar Ausencia</h2>
                <button className="modal-close" onClick={() => { setRejectingId(null); setRejectReason(''); }}>×</button>
              </div>
              <div className="modal-body">
                <div className="form-group">
                  <label htmlFor="reject-reason" className="form-label">Razón del rechazo *</label>
                  <textarea
                    id="reject-reason"
                    className="form-input"
                    rows={4}
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="Ingresa la razón del rechazo..."
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => { setRejectingId(null); setRejectReason(''); }}>
                  Cancelar
                </button>
                <button className="btn btn-reject" onClick={() => handleReject(rejectingId)}>
                  Rechazar
                </button>
              </div>
            </div>
          </div>
        )}

        {loading && (
          <div className="loading-overlay">
            <div className="loading-spinner">Cargando...</div>
          </div>
        )}

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Ausencias;

