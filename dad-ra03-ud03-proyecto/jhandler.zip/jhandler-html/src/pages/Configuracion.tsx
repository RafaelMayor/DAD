import React, { useState, useEffect, useRef } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useI18n } from '../contexts/I18nContext';
import './Configuracion.css';

type TabType = 'perfil' | 'preferencias' | 'accesibilidad' | 'roles';

const Configuracion: React.FC = () => {
  const { user, logout, updateUser } = useAuth();
  const { theme, toggleTheme, setTheme } = useTheme();
  const { language, setLanguage, t } = useI18n();
  const [activeTab, setActiveTab] = useState<TabType>('perfil');
  
  // Estado de accesibilidad
  const [fontSize, setFontSize] = useState<'small' | 'medium' | 'large'>(() => {
    const saved = localStorage.getItem('fontSize') as 'small' | 'medium' | 'large';
    return saved || 'medium';
  });
  const [highContrast, setHighContrast] = useState(() => {
    return localStorage.getItem('highContrast') === 'true';
  });
  const [reduceMotion, setReduceMotion] = useState(() => {
    return localStorage.getItem('reduceMotion') === 'true';
  });
  const [screenReader, setScreenReader] = useState(() => {
    return localStorage.getItem('screenReader') === 'true';
  });
  const [focusVisible, setFocusVisible] = useState(() => {
    return localStorage.getItem('focusVisible') === 'true';
  });
  
  // Estado del formulario de perfil
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    phone: '',
    position: '',
    department: ''
  });
  
  const [originalFormData, setOriginalFormData] = useState({
    email: '',
    name: '',
    phone: '',
    position: '',
    department: ''
  });
  
  const [profilePhoto, setProfilePhoto] = useState<string>('');
  const [originalProfilePhoto, setOriginalProfilePhoto] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Cargar datos del usuario
  useEffect(() => {
    if (user) {
      const userData = {
        email: user.email || '',
        name: user.name || '',
        phone: (user as any).phone || '',
        position: (user as any).position || '',
        department: (user as any).department || ''
      };
      setFormData(userData);
      setOriginalFormData(userData);
      
      const photo = (user as any).profilePhoto || '';
      setProfilePhoto(photo);
      setOriginalProfilePhoto(photo);
    }
  }, [user]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setSaveMessage(null);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validar que sea una imagen
      if (!file.type.startsWith('image/')) {
        setSaveMessage({ type: 'error', text: 'Por favor, selecciona un archivo de imagen' });
        return;
      }
      
      // Validar tamaño (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setSaveMessage({ type: 'error', text: 'La imagen no debe superar los 5MB' });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setProfilePhoto(result);
        setSaveMessage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReset = () => {
    setFormData(originalFormData);
    setProfilePhoto(originalProfilePhoto);
    setSaveMessage(null);
  };

  const handleSave = async () => {
    if (!user) return;

    setIsSaving(true);
    setSaveMessage(null);

    try {
      if (!window.electronAPI?.auth) {
        setSaveMessage({ type: 'error', text: 'La aplicación no está ejecutándose en Electron' });
        setIsSaving(false);
        return;
      }

      const result = await window.electronAPI.auth.updateProfile(
        user.id,
        formData.email,
        formData.name,
        formData.phone || undefined,
        formData.position || undefined,
        profilePhoto || undefined,
        undefined,
        formData.department || undefined
      );

      if (result.success && result.user) {
        setOriginalFormData(formData);
        setOriginalProfilePhoto(profilePhoto);
        setSaveMessage({ type: 'success', text: 'Perfil actualizado correctamente' });
        
        // Actualizar el usuario en el contexto
        updateUser(result.user);
        
        setTimeout(() => {
          setSaveMessage(null);
        }, 3000);
      } else {
        setSaveMessage({ type: 'error', text: result.error || 'Error al actualizar el perfil' });
      }
    } catch (error: any) {
      console.error('Error al guardar perfil:', error);
      setSaveMessage({ type: 'error', text: error.message || 'Error al guardar los cambios' });
    } finally {
      setIsSaving(false);
    }
  };

  const hasChanges = () => {
    return (
      formData.email !== originalFormData.email ||
      formData.name !== originalFormData.name ||
      formData.phone !== originalFormData.phone ||
      formData.position !== originalFormData.position ||
      formData.department !== originalFormData.department ||
      profilePhoto !== originalProfilePhoto
    );
  };

  // Efectos para aplicar preferencias de accesibilidad
  useEffect(() => {
    document.documentElement.setAttribute('data-font-size', fontSize);
    localStorage.setItem('fontSize', fontSize);
  }, [fontSize]);

  useEffect(() => {
    if (highContrast) {
      document.documentElement.setAttribute('data-high-contrast', 'true');
    } else {
      document.documentElement.removeAttribute('data-high-contrast');
    }
    localStorage.setItem('highContrast', String(highContrast));
  }, [highContrast]);

  useEffect(() => {
    if (reduceMotion) {
      document.documentElement.setAttribute('data-reduce-motion', 'true');
    } else {
      document.documentElement.removeAttribute('data-reduce-motion');
    }
    localStorage.setItem('reduceMotion', String(reduceMotion));
  }, [reduceMotion]);

  useEffect(() => {
    if (screenReader) {
      document.documentElement.setAttribute('data-screen-reader', 'true');
    } else {
      document.documentElement.removeAttribute('data-screen-reader');
    }
    localStorage.setItem('screenReader', String(screenReader));
  }, [screenReader]);

  useEffect(() => {
    if (focusVisible) {
      document.documentElement.setAttribute('data-focus-visible', 'true');
    } else {
      document.documentElement.removeAttribute('data-focus-visible');
    }
    localStorage.setItem('focusVisible', String(focusVisible));
  }, [focusVisible]);

  const tabs = [
    { id: 'perfil' as TabType, label: t('settings.profile'), icon: 'fa-solid fa-user' },
    { id: 'preferencias' as TabType, label: t('settings.preferences'), icon: 'fa-solid fa-user-gear' },
    { id: 'accesibilidad' as TabType, label: t('settings.accessibility'), icon: 'fa-solid fa-universal-access' },
    { id: 'roles' as TabType, label: t('settings.roles'), icon: 'fa-solid fa-shield-halved' }
  ];

  return (
    <Layout>
      <div className="configuracion-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">{t('settings.title')}</h1>
            <p className="page-subtitle">{t('settings.subtitle')}</p>
          </div>
          <div className="user-profile-header">
            <div className="user-info">
              <img
                className="user-avatar"
                src={profilePhoto || (user as any)?.profilePhoto || 'https://c.animaapp.com/6eePod7j/img/img@2x.png'}
                alt={user?.name || 'Usuario'}
              />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>

        <section className="content-section">
          <div className="config-card">
            <nav className="tabs-navigation" role="tablist">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
                  role="tab"
                  aria-selected={activeTab === tab.id}
                  onClick={() => setActiveTab(tab.id)}
                >
                  <i className={tab.icon}></i>
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>

            <div className="tab-content">
              {activeTab === 'perfil' && (
                <div className="profile-tab" role="tabpanel">
                  <form className="profile-form" onSubmit={(e) => { e.preventDefault(); handleSave(); }}>
                    <h3 className="form-title">
                      <i className="fa-solid fa-user"></i>
                      {t('profile.title')}
                    </h3>

                    <div className="form-content">
                      <div className="form-fields">
                        <div className="form-group">
                          <label htmlFor="name" className="form-label">
                            {t('profile.name')}
                          </label>
                          <div className="input-wrapper">
                            <input
                              type="text"
                              id="name"
                              name="name"
                              className="form-input"
                              value={formData.name}
                              onChange={handleInputChange}
                              required
                            />
                          </div>
                        </div>

                        <div className="form-group">
                          <label htmlFor="email" className="form-label">
                            {t('profile.email')}
                          </label>
                          <div className="input-wrapper">
                            <input
                              type="email"
                              id="email"
                              name="email"
                              className="form-input"
                              value={formData.email}
                              onChange={handleInputChange}
                              required
                            />
                          </div>
                        </div>

                        <div className="form-group">
                          <label htmlFor="phone" className="form-label">
                            {t('profile.phone')}
                          </label>
                          <div className="input-wrapper">
                            <input
                              type="tel"
                              id="phone"
                              name="phone"
                              className="form-input"
                              value={formData.phone}
                              onChange={handleInputChange}
                            />
                          </div>
                        </div>

                        <div className="form-group">
                          <label htmlFor="position" className="form-label">
                            {t('profile.position')}
                          </label>
                          <div className="input-wrapper">
                            <input
                              type="text"
                              id="position"
                              name="position"
                              className="form-input"
                              value={formData.position}
                              onChange={handleInputChange}
                            />
                          </div>
                        </div>

                        <div className="form-group">
                          <label htmlFor="department" className="form-label">
                            {t('profile.department')}
                          </label>
                          <div className="input-wrapper">
                            <select
                              id="department"
                              name="department"
                              className="form-input"
                              value={formData.department}
                              onChange={handleInputChange}
                            >
                              <option value="">Seleccionar departamento</option>
                              <option value="Administración">Administración</option>
                              <option value="Recursos Humanos">Recursos Humanos</option>
                              <option value="Tecnología">Tecnología</option>
                              <option value="Marketing">Marketing</option>
                              <option value="Ventas">Ventas</option>
                              <option value="Finanzas">Finanzas</option>
                              <option value="Operaciones">Operaciones</option>
                            </select>
                          </div>
                        </div>

                        {saveMessage && (
                          <div className={`save-message ${saveMessage.type}`}>
                            {saveMessage.text}
                          </div>
                        )}

                        <div className="form-actions">
                          <button
                            type="button"
                            className="btn-reset"
                            onClick={handleReset}
                            disabled={!hasChanges() || isSaving}
                          >
                            {t('profile.reset')}
                          </button>
                          <button
                            type="submit"
                            className="btn-save"
                            disabled={!hasChanges() || isSaving}
                          >
                            <i className="fa-solid fa-floppy-disk"></i>
                            <span>{isSaving ? t('profile.saving') : t('profile.save')}</span>
                          </button>
                        </div>
                      </div>

                      <div className="profile-photo-section">
                        <div className="photo-wrapper">
                          <img
                            className="profile-photo"
                            src={profilePhoto || 'https://c.animaapp.com/0gplIWYw/img/img.svg'}
                            alt="Foto de perfil"
                          />
                          <button
                            type="button"
                            className="camera-button"
                            onClick={() => fileInputRef.current?.click()}
                            aria-label="Cambiar foto de perfil"
                          >
                            <i className="fa-solid fa-camera"></i>
                          </button>
                        </div>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          style={{ display: 'none' }}
                        />
                      </div>
                    </div>
                  </form>

                  <div className="logout-section">
                    <button className="btn-logout" onClick={logout}>
                      {t('profile.logout')}
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'preferencias' && (
                <div className="tab-panel" role="tabpanel">
                  <h3 className="panel-title">{t('preferences.title')}</h3>
                  <p className="panel-description">{t('preferences.description')}</p>
                  
                  <div className="preferences-content">
                    <div className="preference-group">
                      <div className="preference-item">
                        <div className="preference-label">
                          <i className="fa-solid fa-palette"></i>
                          <span>{t('preferences.theme')}</span>
                        </div>
                        <div className="preference-control">
                          <div className="theme-toggle">
                            <button
                              type="button"
                              className={`theme-option ${theme === 'light' ? 'active' : ''}`}
                              onClick={() => setTheme('light')}
                            >
                              <i className="fa-solid fa-sun"></i>
                              <span>{t('preferences.theme.light')}</span>
                            </button>
                            <button
                              type="button"
                              className={`theme-option ${theme === 'dark' ? 'active' : ''}`}
                              onClick={() => setTheme('dark')}
                            >
                              <i className="fa-solid fa-moon"></i>
                              <span>{t('preferences.theme.dark')}</span>
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="preference-item">
                        <div className="preference-label">
                          <i className="fa-solid fa-language"></i>
                          <span>{t('preferences.language')}</span>
                        </div>
                        <div className="preference-control">
                          <select
                            className="language-select"
                            value={language}
                            onChange={(e) => setLanguage(e.target.value as 'es' | 'en')}
                          >
                            <option value="es">{t('preferences.language.spanish')}</option>
                            <option value="en">{t('preferences.language.english')}</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'accesibilidad' && (
                <div className="tab-panel" role="tabpanel">
                  <h3 className="panel-title">{t('accessibility.title')}</h3>
                  <p className="panel-description">{t('accessibility.description')}</p>
                  
                  <div className="accessibility-content">
                    <div className="accessibility-group">
                      <div className="accessibility-item">
                        <div className="accessibility-label">
                          <i className="fa-solid fa-text-height"></i>
                          <div>
                            <span className="label-text">{t('accessibility.fontSize')}</span>
                            <span className="label-description">Ajusta el tamaño del texto para mejorar la legibilidad</span>
                          </div>
                        </div>
                        <div className="accessibility-control">
                          <div className="font-size-options">
                            <button
                              type="button"
                              className={`font-size-option ${fontSize === 'small' ? 'active' : ''}`}
                              onClick={() => setFontSize('small')}
                            >
                              {t('accessibility.fontSize.small')}
                            </button>
                            <button
                              type="button"
                              className={`font-size-option ${fontSize === 'medium' ? 'active' : ''}`}
                              onClick={() => setFontSize('medium')}
                            >
                              {t('accessibility.fontSize.medium')}
                            </button>
                            <button
                              type="button"
                              className={`font-size-option ${fontSize === 'large' ? 'active' : ''}`}
                              onClick={() => setFontSize('large')}
                            >
                              {t('accessibility.fontSize.large')}
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="accessibility-item">
                        <div className="accessibility-label">
                          <i className="fa-solid fa-circle-half-stroke"></i>
                          <div>
                            <span className="label-text">{t('accessibility.highContrast')}</span>
                            <span className="label-description">Aumenta el contraste entre texto y fondo</span>
                          </div>
                        </div>
                        <div className="accessibility-control">
                          <label className="toggle-switch">
                            <input
                              type="checkbox"
                              checked={highContrast}
                              onChange={(e) => setHighContrast(e.target.checked)}
                            />
                            <span className="toggle-slider"></span>
                          </label>
                        </div>
                      </div>

                      <div className="accessibility-item">
                        <div className="accessibility-label">
                          <i className="fa-solid fa-stop"></i>
                          <div>
                            <span className="label-text">{t('accessibility.reduceMotion')}</span>
                            <span className="label-description">Reduce las animaciones y transiciones</span>
                          </div>
                        </div>
                        <div className="accessibility-control">
                          <label className="toggle-switch">
                            <input
                              type="checkbox"
                              checked={reduceMotion}
                              onChange={(e) => setReduceMotion(e.target.checked)}
                            />
                            <span className="toggle-slider"></span>
                          </label>
                        </div>
                      </div>

                      <div className="accessibility-item">
                        <div className="accessibility-label">
                          <i className="fa-solid fa-headphones"></i>
                          <div>
                            <span className="label-text">{t('accessibility.screenReader')}</span>
                            <span className="label-description">Optimiza la aplicación para lectores de pantalla</span>
                          </div>
                        </div>
                        <div className="accessibility-control">
                          <label className="toggle-switch">
                            <input
                              type="checkbox"
                              checked={screenReader}
                              onChange={(e) => setScreenReader(e.target.checked)}
                            />
                            <span className="toggle-slider"></span>
                          </label>
                        </div>
                      </div>

                      <div className="accessibility-item">
                        <div className="accessibility-label">
                          <i className="fa-solid fa-bullseye"></i>
                          <div>
                            <span className="label-text">{t('accessibility.focusVisible')}</span>
                            <span className="label-description">Resalta los elementos enfocados con el teclado</span>
                          </div>
                        </div>
                        <div className="accessibility-control">
                          <label className="toggle-switch">
                            <input
                              type="checkbox"
                              checked={focusVisible}
                              onChange={(e) => setFocusVisible(e.target.checked)}
                            />
                            <span className="toggle-slider"></span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'roles' && (
                <div className="tab-panel" role="tabpanel">
                  <h3 className="panel-title">Roles y Permisos</h3>
                  <p className="panel-description">Gestiona los roles y permisos de los usuarios</p>
                  <div className="coming-soon">
                    <i className="fa-solid fa-shield-halved"></i>
                    <p>Próximamente disponible</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Configuracion;
