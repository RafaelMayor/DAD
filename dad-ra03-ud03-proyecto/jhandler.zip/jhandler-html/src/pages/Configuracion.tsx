import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import './Configuracion.css';

const Configuracion: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <Layout>
      <div className="configuracion-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Configuración</h1>
            <p className="page-subtitle">Ajustes del sistema</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <img
                className="user-avatar"
                src="https://c.animaapp.com/6eePod7j/img/img@2x.png"
                alt={user?.name || 'Usuario'}
              />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">Configuración</h2>
          </div>
          <div className="config-content">
            <div className="config-section">
              <h3 className="config-section-title">Cuenta</h3>
              <div className="config-item">
                <label className="config-label">Email</label>
                <input type="email" className="config-input" value={user?.email || ''} readOnly />
              </div>
              <div className="config-item">
                <label className="config-label">Nombre</label>
                <input type="text" className="config-input" value={user?.name || ''} readOnly />
              </div>
            </div>
            <div className="config-section">
              <h3 className="config-section-title">Sesión</h3>
              <button className="btn btn-secondary" onClick={logout}>
                Cerrar Sesión
              </button>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Configuracion;

