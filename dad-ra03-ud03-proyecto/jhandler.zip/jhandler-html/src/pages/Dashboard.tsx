import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import './Dashboard.css';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    { label: 'Empleados Activos', value: '247', icon: 'fa-solid fa-users', color: '#2A9D8F' },
    { label: 'Ausencias Hoy', value: '12', icon: 'fa-solid fa-calendar-xmark', color: '#E9C46A' },
    { label: 'Solicitudes Pendientes', value: '8', icon: 'fa-solid fa-clock', color: '#F4A261' },
    { label: 'Cumpleaños', value: '3', icon: 'fa-solid fa-cake-candles', color: '#E76F51' }
  ];

  return (
    <Layout>
      <div className="dashboard">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Dashboard</h1>
            <p className="page-subtitle">Resumen general de recursos humanos</p>
          </div>
          <div className="header-actions">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-profile">
              <div className="user-avatar" role="img" aria-label={`Avatar de ${user?.name}`}></div>
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <div className="content-background">
          <section className="stats-section" aria-label="Estadísticas principales">
            {stats.map((stat, index) => (
              <article key={index} className="stat-card">
                <div className="stat-content">
                  <h2 className="stat-label">{stat.label}</h2>
                  <p className="stat-value">{stat.value}</p>
                </div>
                <div
                  className="stat-icon-wrapper"
                  style={{ backgroundColor: `${stat.color}1A` }} // ~10% opacity
                >
                  <i className={`${stat.icon} stat-icon`} style={{ color: stat.color }}></i>
                </div>
              </article>
            ))}
          </section>
          <div className="dashboard-grid">
            <section className="chart-section" aria-labelledby="chart-title">
              <h2 id="chart-title" className="section-title">
                Empleados por Departamento
              </h2>
            </section>
            <section className="actions-section" aria-labelledby="actions-title">
              <h2 id="actions-title" className="section-title">
                Acciones Rápidas
              </h2>
              <div className="action-buttons">
                <button className="action-button action-button-primary">
                  <i className="fa-solid fa-user-plus action-icon"></i>
                  <span className="action-text">Añadir Empleado</span>
                </button>
                <button className="action-button action-button-secondary">
                  <i className="fa-solid fa-file-export action-icon"></i>
                  <span className="action-text">Generar Informe</span>
                </button>
                <button className="action-button action-button-tertiary">
                  <i className="fa-solid fa-calendar-check action-icon"></i>
                  <span className="action-text">Gestionar Ausencias</span>
                </button>
              </div>
            </section>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;

