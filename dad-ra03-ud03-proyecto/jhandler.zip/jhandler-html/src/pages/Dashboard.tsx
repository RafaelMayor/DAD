import React from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import UserAvatar from '../components/UserAvatar';
import { usePermissions } from '../hooks/usePermissions';
import { useI18n } from '../contexts/I18nContext';
import './Dashboard.css';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const permissions = usePermissions();
  const navigate = useNavigate();
  const { t } = useI18n();

  const stats = [
    { label: t('dashboard.activeEmployees'), value: '247', icon: 'fa-solid fa-users', color: '#2A9D8F' },
    { label: t('dashboard.absencesToday'), value: '12', icon: 'fa-solid fa-calendar-xmark', color: '#E9C46A' },
    { label: t('dashboard.pendingRequests'), value: '8', icon: 'fa-solid fa-clock', color: '#F4A261' },
    { label: t('dashboard.birthdays'), value: '3', icon: 'fa-solid fa-cake-candles', color: '#E76F51' }
  ];

  return (
    <Layout>
      <div className="dashboard">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">{t('dashboard.title')}</h1>
            <p className="page-subtitle">{t('dashboard.subtitle')}</p>
          </div>
          <div className="header-actions">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-profile">
              <UserAvatar size={42} className="user-avatar" />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <div className="content-background">
          <section className="stats-section" aria-label="Estadísticas principales">
            {stats.map((stat, index) => (
              <article key={index} className="stat-card">
                <div className="stat-content">
                  <h2 className="stat-label">{stat.label}</h2>
                  <p className="stat-value">{stat.value}</p>
                </div>
                <div
                  className="stat-icon-wrapper"
                  style={{ backgroundColor: `${stat.color}1A` }} // ~10% opacity
                >
                  <i className={`${stat.icon} stat-icon`} style={{ color: stat.color }}></i>
                </div>
              </article>
            ))}
          </section>
          <div className="dashboard-grid">
            <section className="chart-section" aria-labelledby="chart-title">
              <h2 id="chart-title" className="section-title">
                Empleados por Departamento
              </h2>
            </section>
            <section className="actions-section" aria-labelledby="actions-title">
              <h2 id="actions-title" className="section-title">
                {t('dashboard.quickActions')}
              </h2>
              <div className="action-buttons">
                {permissions.canManageUsers ? (
                  <>
                    <button 
                      className="action-button action-button-primary"
                      onClick={() => navigate('/empleados')}
                    >
                      <i className="fa-solid fa-user-plus action-icon"></i>
                      <span className="action-text">{t('dashboard.addEmployee')}</span>
                    </button>
                    <button 
                      className="action-button action-button-secondary"
                      onClick={() => navigate('/informes')}
                    >
                      <i className="fa-solid fa-file-export action-icon"></i>
                      <span className="action-text">{t('dashboard.generateReport')}</span>
                    </button>
                    <button 
                      className="action-button action-button-tertiary"
                      onClick={() => navigate('/ausencias')}
                    >
                      <i className="fa-solid fa-calendar-check action-icon"></i>
                      <span className="action-text">{t('dashboard.manageAbsences')}</span>
                    </button>
                  </>
                ) : (
                  <>
                    <button 
                      className="action-button action-button-primary"
                      onClick={() => navigate('/ausencias')}
                    >
                      <i className="fa-solid fa-calendar-plus action-icon"></i>
                      <span className="action-text">{t('dashboard.requestAbsence')}</span>
                    </button>
                    <button 
                      className="action-button action-button-secondary"
                      onClick={() => navigate('/nominas')}
                    >
                      <i className="fa-solid fa-file-invoice-dollar action-icon"></i>
                      <span className="action-text">{t('dashboard.viewMyPayroll')}</span>
                    </button>
                    <button 
                      className="action-button action-button-tertiary"
                      onClick={() => navigate('/informes')}
                    >
                      <i className="fa-solid fa-chart-bar action-icon"></i>
                      <span className="action-text">{t('dashboard.viewMyReports')}</span>
                    </button>
                  </>
                )}
              </div>
            </section>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;

