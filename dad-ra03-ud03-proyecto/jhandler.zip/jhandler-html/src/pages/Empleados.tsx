import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import UserAvatar from '../components/UserAvatar';
import { usePermissions } from '../hooks/usePermissions';
import './Empleados.css';

interface Employee {
  id: number;
  email: string;
  name: string;
  phone?: string;
  position?: string;
  profilePhoto?: string;
  role: string;
  department?: string;
  createdAt: string;
}

const Empleados: React.FC = () => {
  const { user } = useAuth();
  const permissions = usePermissions();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('');
  const [filterPosition, setFilterPosition] = useState('');
  const [filterRole, setFilterRole] = useState('');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    role: 'Empleado',
    department: '',
    position: ''
  });
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Cargar empleados
  useEffect(() => {
    loadEmployees();
  }, []);

  // Filtrar empleados cuando cambian los filtros o búsqueda
  useEffect(() => {
    filterEmployees();
  }, [searchTerm, filterDepartment, filterPosition, filterRole, employees]);

  const loadEmployees = async () => {
    try {
      setLoading(true);
      if (window.electronAPI?.employees) {
        const allEmployees = await window.electronAPI.employees.getAll();
        setEmployees(allEmployees);
      }
    } catch (error) {
      console.error('Error al cargar empleados:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterEmployees = () => {
    let filtered = [...employees];

    // Filtro de búsqueda
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(emp =>
        emp.name.toLowerCase().includes(searchLower) ||
        emp.email.toLowerCase().includes(searchLower) ||
        (emp.position && emp.position.toLowerCase().includes(searchLower)) ||
        (emp.department && emp.department.toLowerCase().includes(searchLower))
      );
    }

    // Filtro por departamento
    if (filterDepartment) {
      filtered = filtered.filter(emp => emp.department === filterDepartment);
    }

    // Filtro por cargo
    if (filterPosition) {
      filtered = filtered.filter(emp => emp.position === filterPosition);
    }

    // Filtro por rol
    if (filterRole) {
      filtered = filtered.filter(emp => emp.role === filterRole);
    }

    setFilteredEmployees(filtered);
  };

  const handleOpenModal = () => {
    setShowModal(true);
    setFormData({
      email: '',
      password: '',
      name: '',
      role: 'Empleado',
      department: '',
      position: ''
    });
    setFormError('');
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setFormError('');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setFormError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setIsSubmitting(true);

    try {
      // Validaciones
      if (!formData.email || !formData.password || !formData.name) {
        setFormError('Todos los campos obligatorios deben estar completos');
        setIsSubmitting(false);
        return;
      }

      if (formData.password.length < 6) {
        setFormError('La contraseña debe tener al menos 6 caracteres');
        setIsSubmitting(false);
        return;
      }

      // Validar rol según el usuario actual
      const currentUserRole = user?.role;
      if (currentUserRole === 'Gerente' && formData.role === 'Administrador') {
        setFormError('Los gerentes no pueden crear usuarios administradores');
        setIsSubmitting(false);
        return;
      }

      if (!window.electronAPI?.employees) {
        setFormError('La aplicación no está ejecutándose en Electron');
        setIsSubmitting(false);
        return;
      }

      const result = await window.electronAPI.employees.create(
        formData.email,
        formData.password,
        formData.name,
        formData.role,
        formData.department || undefined,
        formData.position || undefined
      );

      if (result.success) {
        handleCloseModal();
        await loadEmployees();
      } else {
        setFormError(result.error || 'Error al crear el empleado');
      }
    } catch (error: any) {
      console.error('Error al crear empleado:', error);
      setFormError(error.message || 'Error al crear el empleado');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Obtener opciones únicas para los filtros
  const departments = Array.from(new Set(employees.map(emp => emp.department).filter(Boolean))) as string[];
  const positions = Array.from(new Set(employees.map(emp => emp.position).filter(Boolean))) as string[];
  const roles = Array.from(new Set(employees.map(emp => emp.role).filter(Boolean))) as string[];

  // Determinar roles disponibles según el usuario actual
  const availableRoles = user?.role === 'Administrador'
    ? ['Empleado', 'Gerente', 'Administrador']
    : user?.role === 'Gerente'
      ? ['Empleado', 'Gerente']
      : [];

  return (
    <Layout>
      <div className="empleados-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Empleados</h1>
            <p className="page-subtitle">Gestión de empleados</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <UserAvatar size={42} className="user-avatar" />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">Lista de empleados</h2>
            {permissions.canCreateUsers && (
              <div className="section-actions">
                <button className="btn btn-primary" onClick={handleOpenModal}>
                  <i className="fa-solid fa-plus"></i>
                  <span className="btn-text">Añadir Empleado</span>
                </button>
              </div>
            )}
          </div>

          {/* Búsqueda y Filtros */}
          <div className="search-section">
            <div className="search-container">
              <svg className="search-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path
                  d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z"
                  stroke="#6B7280"
                  strokeWidth="1.66667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <input
                type="search"
                className="search-input"
                placeholder="Buscar empleado por nombre, email, cargo o departamento..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="filters-container">
              <div className="filter-group">
                <label htmlFor="filter-department" className="filter-label">Departamento</label>
                <select
                  id="filter-department"
                  className="filter-select"
                  value={filterDepartment}
                  onChange={(e) => setFilterDepartment(e.target.value)}
                >
                  <option value="">Todos los departamentos</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label htmlFor="filter-position" className="filter-label">Cargo</label>
                <select
                  id="filter-position"
                  className="filter-select"
                  value={filterPosition}
                  onChange={(e) => setFilterPosition(e.target.value)}
                >
                  <option value="">Todos los cargos</option>
                  {positions.map(pos => (
                    <option key={pos} value={pos}>{pos}</option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label htmlFor="filter-role" className="filter-label">Rol</label>
                <select
                  id="filter-role"
                  className="filter-select"
                  value={filterRole}
                  onChange={(e) => setFilterRole(e.target.value)}
                >
                  <option value="">Todos los roles</option>
                  {roles.map(role => (
                    <option key={role} value={role}>{role}</option>
                  ))}
                </select>
              </div>

              {(filterDepartment || filterPosition || filterRole) && (
                <button
                  className="btn-clear-filters"
                  onClick={() => {
                    setFilterDepartment('');
                    setFilterPosition('');
                    setFilterRole('');
                  }}
                >
                  Limpiar filtros
                </button>
              )}
            </div>
          </div>

          {/* Lista de empleados */}
          <div className="employees-list">
            {loading ? (
              <p className="empty-message">Cargando empleados...</p>
            ) : filteredEmployees.length === 0 ? (
              <p className="empty-message">
                {employees.length === 0
                  ? 'No hay empleados registrados'
                  : 'No se encontraron empleados con los filtros aplicados'}
              </p>
            ) : (
              <div className="employees-table">
                <table className="employees-table-content">
                  <thead>
                    <tr>
                      <th>Nombre</th>
                      <th>Email</th>
                      <th>Cargo</th>
                      <th>Departamento</th>
                      <th>Rol</th>
                      <th>Teléfono</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredEmployees.map(employee => (
                      <tr key={employee.id}>
                        <td>
                          <div className="employee-name-cell">
                            {employee.profilePhoto ? (
                              <img
                                src={employee.profilePhoto}
                                alt={employee.name}
                                className="employee-avatar-small"
                              />
                            ) : (
                              <div className="employee-avatar-small employee-avatar-placeholder">
                                {employee.name.charAt(0).toUpperCase()}
                              </div>
                            )}
                            <span>{employee.name}</span>
                          </div>
                        </td>
                        <td>{employee.email}</td>
                        <td>{employee.position || '-'}</td>
                        <td>{employee.department || '-'}</td>
                        <td>
                          <span className={`role-badge role-${employee.role.toLowerCase()}`}>
                            {employee.role}
                          </span>
                        </td>
                        <td>{employee.phone || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </section>

        {/* Modal para añadir empleado */}
        {showModal && (
          <div className="modal-overlay" onClick={handleCloseModal}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2 className="modal-title">Añadir Nuevo Empleado</h2>
                <button className="modal-close" onClick={handleCloseModal}>
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
              <form onSubmit={handleSubmit} className="modal-form">
                {formError && (
                  <div className="form-error">
                    {formError}
                  </div>
                )}
                <div className="form-group">
                  <label htmlFor="name" className="form-label">
                    Nombre completo <span className="required">*</span>
                  </label>
                  <div className="input-wrapper">
                    <input
                      type="text"
                      id="name"
                      name="name"
                      className="form-input"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="email" className="form-label">
                    Email <span className="required">*</span>
                  </label>
                  <div className="input-wrapper">
                    <input
                      type="email"
                      id="email"
                      name="email"
                      className="form-input"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="password" className="form-label">
                    Contraseña <span className="required">*</span>
                  </label>
                  <div className="input-wrapper">
                    <input
                      type="password"
                      id="password"
                      name="password"
                      className="form-input"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                      minLength={6}
                    />
                  </div>
                  <small className="form-hint">Mínimo 6 caracteres</small>
                </div>

                <div className="form-group">
                  <label htmlFor="role" className="form-label">
                    Rol <span className="required">*</span>
                  </label>
                  <div className="input-wrapper">
                    <select
                      id="role"
                      name="role"
                      className="form-input"
                      value={formData.role}
                      onChange={handleInputChange}
                      required
                    >
                      {availableRoles.map(role => (
                        <option key={role} value={role}>{role}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="department" className="form-label">
                    Departamento
                  </label>
                  <div className="input-wrapper">
                    <select
                      id="department"
                      name="department"
                      className="form-input"
                      value={formData.department}
                      onChange={handleInputChange}
                    >
                      <option value="">Seleccionar departamento</option>
                      <option value="Administración">Administración</option>
                      <option value="Recursos Humanos">Recursos Humanos</option>
                      <option value="Tecnología">Tecnología</option>
                      <option value="Marketing">Marketing</option>
                      <option value="Ventas">Ventas</option>
                      <option value="Finanzas">Finanzas</option>
                      <option value="Operaciones">Operaciones</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="position" className="form-label">
                    Cargo
                  </label>
                  <div className="input-wrapper">
                    <input
                      type="text"
                      id="position"
                      name="position"
                      className="form-input"
                      value={formData.position}
                      onChange={handleInputChange}
                      placeholder="Ej: Desarrollador, Gerente de Ventas, etc."
                    />
                  </div>
                </div>

                <div className="modal-actions">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={handleCloseModal}
                    disabled={isSubmitting}
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Creando...' : 'Crear Empleado'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Empleados;
