import React, { useState } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import './Empleados.css';

const Empleados: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <Layout>
      <div className="empleados-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Empleados</h1>
            <p className="page-subtitle">Gestión de empleados</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <img
                className="user-avatar"
                src="https://c.animaapp.com/sqKWeGVA/img/img@2x.png"
                alt={user?.name || 'Usuario'}
              />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">Lista de empleados</h2>
            <div className="section-actions">
              <button className="btn btn-primary">
                <span className="btn-text">Añadir Empleado</span>
              </button>
            </div>
          </div>
          <div className="search-section">
            <div className="search-container">
              <svg className="search-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path
                  d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z"
                  stroke="#6B7280"
                  strokeWidth="1.66667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <input
                type="search"
                className="search-input"
                placeholder="Buscar empleado..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="employees-list">
            <p className="empty-message">Lista de empleados - Funcionalidad en desarrollo</p>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Empleados;

