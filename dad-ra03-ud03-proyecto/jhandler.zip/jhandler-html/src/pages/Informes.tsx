import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import './Informes.css';

const Informes: React.FC = () => {
  const { user } = useAuth();

  return (
    <Layout>
      <div className="informes-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Informes</h1>
            <p className="page-subtitle">Gestión de informes</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <img
                className="user-avatar"
                src="https://c.animaapp.com/YbasNYIz/img/img@2x.png"
                alt={user?.name || 'Usuario'}
              />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">Generar informes</h2>
            <div className="section-actions">
              <button className="btn btn-primary">
                <span className="btn-text">Nuevo Informe</span>
              </button>
            </div>
          </div>
          <div className="informes-content">
            <p className="empty-message">Generación de informes - Funcionalidad en desarrollo</p>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Informes;

