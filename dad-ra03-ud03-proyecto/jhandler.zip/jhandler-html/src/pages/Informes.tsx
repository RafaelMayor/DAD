import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import UserAvatar from '../components/UserAvatar';
import { usePermissions } from '../hooks/usePermissions';
import './Informes.css';

const Informes: React.FC = () => {
  const { user } = useAuth();
  const permissions = usePermissions();

  return (
    <Layout>
      <div className="informes-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Informes</h1>
            <p className="page-subtitle">Gestión de informes</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <UserAvatar size={42} className="user-avatar" />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">{permissions.canManageInformes ? 'Generar informes' : 'Mis Informes'}</h2>
            {permissions.canManageInformes && (
              <div className="section-actions">
                <button className="btn btn-primary">
                  <span className="btn-text">Nuevo Informe</span>
                </button>
              </div>
            )}
          </div>
          <div className="informes-content">
            <p className="empty-message">Generación de informes - Funcionalidad en desarrollo</p>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Informes;

