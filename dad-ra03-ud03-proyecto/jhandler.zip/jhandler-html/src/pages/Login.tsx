import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './Login.css';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Por favor, completa todos los campos');
      return;
    }

    const result = await login(email, password);
    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.error || 'Credenciales incorrectas');
    }
  };

  return (
    <main className="login">
      <div className="login-background"></div>
      <form className="login-form" onSubmit={handleSubmit}>
        <div className="login-header">
          <img
            className="login-logo"
            src="https://c.animaapp.com/uSBeo1j4/img/div.svg"
            alt="Avatar de usuario"
            role="img"
          />
          <h1 className="login-title">jhandler</h1>
          <p className="login-subtitle">TalentoCorp S.L.</p>
        </div>
        {error && <div className="error-message">{error}</div>}
        <div className="form-group">
          <label htmlFor="email" className="form-label">
            Correo electrónico
          </label>
          <div className="input-wrapper">
            <input
              type="email"
              id="email"
              name="email"
              className="form-input"
              placeholder="usuario@talentocorp.com"
              required
              aria-required="true"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        </div>
        <div className="form-group">
          <label htmlFor="password" className="form-label">
            Contraseña
          </label>
          <div className="input-wrapper">
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              name="password"
              className="form-input"
              placeholder="••••••••"
              required
              aria-required="true"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              className="password-toggle-btn"
              onClick={() => setShowPassword(!showPassword)}
              aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
            >
              <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
            </button>
          </div>
        </div>
        <div className="form-actions">
          <button type="submit" className="btn-primary" aria-label="Entrar a la cuenta">
            <span>Entrar</span>
          </button>
        </div>
        <Link to="/forgot-password" className="forgot-password-link">
          ¿Olvidaste tu contraseña?
        </Link>
        <p className="signup-link">
          <span>¿No tienes una cuenta?</span>{' '}
          <Link to="/signup" className="signup-link-text">
            Registrarse
          </Link>
        </p>
      </form>
      <img className="login-icon" src="https://c.animaapp.com/uSBeo1j4/img/icon.svg" alt="" aria-hidden="true" />
    </main>
  );
};

export default Login;

