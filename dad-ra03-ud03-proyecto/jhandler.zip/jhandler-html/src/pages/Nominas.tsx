import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import './Nominas.css';

const Nominas: React.FC = () => {
  const { user } = useAuth();

  return (
    <Layout>
      <div className="nominas-page">
        <header className="page-header">
          <div className="page-title-section">
            <h1 className="page-title">Nóminas</h1>
            <p className="page-subtitle">Gestión de nóminas</p>
          </div>
          <div className="user-profile">
            <button className="notification-button" aria-label="Notificaciones">
              <i className="fa-solid fa-bell notification-icon"></i>
            </button>
            <div className="user-info">
              <img
                className="user-avatar"
                src="https://c.animaapp.com/9EtBXFpW/img/img@2x.png"
                alt={user?.name || 'Usuario'}
              />
              <span className="user-name">{user?.name || 'Usuario'}</span>
            </div>
          </div>
        </header>
        <section className="content-section">
          <div className="section-header">
            <h2 className="section-title">Gestión de nóminas</h2>
            <div className="section-actions">
              <button className="btn btn-primary">
                <span className="btn-text">Generar Nómina</span>
              </button>
            </div>
          </div>
          <div className="nominas-content">
            <p className="empty-message">Gestión de nóminas - Funcionalidad en desarrollo</p>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Nominas;

