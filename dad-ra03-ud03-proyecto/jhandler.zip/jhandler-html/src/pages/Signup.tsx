import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './Signup.css';

const Signup: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Por favor, completa todos los campos');
      return;
    }

    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    const success = await signup(email, password);
    if (success) {
      navigate('/dashboard');
    } else {
      setError('Error al crear la cuenta');
    }
  };

  return (
    <main className="signup">
      <div className="signup-background"></div>
      <form className="signup-form" onSubmit={handleSubmit}>
        <img
          className="signup-logo"
          src="https://c.animaapp.com/qy4bZUoo/img/div.svg"
          alt="Logo de TalentoCorp"
        />
        <h1 className="signup-title">jhandler</h1>
        <p className="signup-subtitle">TalentoCorp S.L.</p>
        {error && <div className="error-message">{error}</div>}
        <div className="form-group">
          <label htmlFor="email" className="form-label">
            Correo electrónico
          </label>
          <input
            type="email"
            id="email"
            name="email"
            className="form-input"
            placeholder="usuario@talentocorp.com"
            required
            autoComplete="email"
            aria-required="true"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="password" className="form-label">
            Contraseña
          </label>
          <div className="password-wrapper">
            <input
              type="password"
              id="password"
              name="password"
              className="form-input"
              placeholder="••••••••"
              required
              autoComplete="new-password"
              aria-required="true"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <img
              className="password-icon"
              src="https://c.animaapp.com/qy4bZUoo/img/icon.svg"
              alt=""
              aria-hidden="true"
            />
          </div>
        </div>
        <div className="form-actions">
          <button type="submit" className="btn-primary">
            <span>Crear cuenta</span>
          </button>
        </div>
        <p className="login-link">
          <span>¿Ya tienes cuenta?</span>{' '}
          <Link to="/login" className="login-link-text">
            Iniciar sesión
          </Link>
        </p>
      </form>
    </main>
  );
};

export default Signup;

