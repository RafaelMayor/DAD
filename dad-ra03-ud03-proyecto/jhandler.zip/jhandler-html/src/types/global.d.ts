declare module '*.css' {
  const content: { [className: string]: string };
  export default content;
}

declare module '*.svg' {
  const content: string;
  export default content;
}

declare module '*.png' {
  const content: string;
  export default content;
}

declare module '*.jpg' {
  const content: string;
  export default content;
}

declare module '*.jpeg' {
  const content: string;
  export default content;
}

declare module '*.gif' {
  const content: string;
  export default content;
}

interface ElectronAPI {
  platform: string;
  versions: {
    node: string;
    chrome: string;
    electron: string;
  };
  auth: {
    login: (email: string, password: string) => Promise<{
      success: boolean;
      user?: { id: number; email: string; name: string; phone?: string; position?: string; profilePhoto?: string; role: string; department?: string; createdAt: string };
      error?: string;
    }>;
    signup: (email: string, password: string, name: string) => Promise<{
      success: boolean;
      user?: { id: number; email: string; name: string; phone?: string; position?: string; profilePhoto?: string; role: string; department?: string; createdAt: string };
      error?: string;
    }>;
    getUserById: (id: number) => Promise<{
      id: number;
      email: string;
      name: string;
      phone?: string;
      position?: string;
      profilePhoto?: string;
      role: string;
      department?: string;
      createdAt: string;
    } | null>;
    updateProfile: (id: number, email: string, name: string, phone?: string, position?: string, profilePhoto?: string, role?: string, department?: string) => Promise<{
      success: boolean;
      user?: { id: number; email: string; name: string; phone?: string; position?: string; profilePhoto?: string; role: string; department?: string; createdAt: string };
      error?: string;
    }>;
  };
  employees: {
    create: (email: string, password: string, name: string, role: string, department?: string, position?: string) => Promise<{
      success: boolean;
      user?: { id: number; email: string; name: string; phone?: string; position?: string; profilePhoto?: string; role: string; department?: string; createdAt: string };
      error?: string;
    }>;
    getAll: () => Promise<Array<{
      id: number;
      email: string;
      name: string;
      phone?: string;
      position?: string;
      profilePhoto?: string;
      role: string;
      department?: string;
      createdAt: string;
    }>>;
  };
  absences: {
    create: (employeeId: number, type: string, description: string, startDate: string, endDate: string) => Promise<{
      success: boolean;
      absence?: any;
      error?: string;
    }>;
    getAll: (filters?: { employeeId?: number; status?: string; startDate?: string; endDate?: string }) => Promise<any[]>;
    approve: (id: number, approvedBy: number) => Promise<{
      success: boolean;
      absence?: any;
      error?: string;
    }>;
    reject: (id: number, approvedBy: number, rejectionReason: string) => Promise<{
      success: boolean;
      absence?: any;
      error?: string;
    }>;
    delete: (id: number) => Promise<{
      success: boolean;
      error?: string;
    }>;
  };
}

declare global {
  interface Window {
    electronAPI?: ElectronAPI;
  }
}

