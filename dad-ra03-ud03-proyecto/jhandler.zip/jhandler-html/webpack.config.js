const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const webpack = require('webpack');

module.exports = (env, argv) => {
  const isProduction = argv.mode === 'production';
  
  return {
    entry: './src/index.tsx',
    target: 'electron-renderer',
    output: {
      path: path.resolve(__dirname, 'dist'),
      filename: 'bundle.js',
      publicPath: isProduction ? './' : '/'
    },
    resolve: {
      extensions: ['.tsx', '.ts', '.js', '.jsx'],
      alias: {
        '@': path.resolve(__dirname, 'src')
      },
      fallback: {
        "path": false,
        "fs": false,
        "events": require.resolve("events/")
      }
    },
    node: {
      __dirname: false,
      __filename: false
    },
    module: {
      rules: [
        {
          test: /\.tsx?$/,
          loader: 'ts-loader',
          exclude: /node_modules/,
          options: {
            transpileOnly: true
          }
        },
        {
          test: /\.css$/,
          use: ['style-loader', 'css-loader']
        },
        {
          test: /\.(png|jpe?g|gif|svg)$/i,
          type: 'asset/resource'
        }
      ]
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: './src/index.html',
        filename: 'index.html'
      }),
      new webpack.ProvidePlugin({
        global: 'globalThis'
      }),
      new webpack.BannerPlugin({
        banner: "(function() { if (typeof global === 'undefined') { var global = globalThis || window || self || this; } })();",
        raw: true,
        entryOnly: true
      })
    ],
    devServer: {
      port: 3000,
      hot: false,
      liveReload: false,
      historyApiFallback: {
        index: '/index.html',
        disableDotRule: true
      },
      open: false,
      compress: true,
      allowedHosts: 'all',
      client: false
    }
  };
};

