import React, { useState } from "react";
import Ventana2 from "./Ventana2";

export default function Ventana1() {
  const [mostrarVentana2, setMostrarVentana2] = useState(false);

  const abrirVentana2 = () => setMostrarVentana2(true);
  const cerrarVentana2 = () => setMostrarVentana2(false);

  return (
    <div style={styles.ventana1}>
      <h1>Ventana 1</h1>
      <button onClick={abrirVentana2}>Abrir Ventana 2</button>

      {mostrarVentana2 && <Ventana2 onCerrar={cerrarVentana2} />}
    </div>
  );
}

const styles = {
  ventana1: {
    textAlign: "center" as const,
    padding: "50px",
  },
};
