import React from "react";

type Ventana2Props = {
  onCerrar: () => void;
};

export default function Ventana2({ onCerrar }: Ventana2Props) {
  return (
    <div style={styles.overlay}>
      <div style={styles.ventana2}>
        <h2>Ventana 2</h2>
        <p>Esta ventana se superpone sobre la ventana 1.</p>
        <button onClick={onCerrar}>Cerrar</button>
      </div>
    </div>
  );
}

const styles = {
  overlay: {
    position: "fixed" as const,
    top: 0,
    left: 0,
    width: "100vw",
    height: "100vh",
    backgroundColor: "rgba(0,0,0,0.5)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  ventana2: {
    backgroundColor: "white",
    padding: "30px",
    borderRadius: "10px",
    boxShadow: "0 0 10px rgba(0,0,0,0.3)",
    textAlign: "center" as const,
  },
};
