import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import Ventana1 from "./components/Ventana1";

const root = ReactDOM.createRoot(document.getElementById("root")!);
root.render(
  <React.StrictMode>
    <Ventana1 />
  </React.StrictMode>
);
