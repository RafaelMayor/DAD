import React from "react";
import ConcursoForm from "./pages/ConcursoForm";

function App() {
  return <ConcursoForm />;
}

export default App;