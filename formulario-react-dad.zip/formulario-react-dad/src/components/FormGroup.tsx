import React from "react";

type FormGroupProps = {
  label: string;
  children: React.ReactNode;
};

const FormGroup: React.FC<FormGroupProps> = ({ label, children }) => {
  return (
    <div className="mb-4">
      <label className="block font-semibold mb-2">{label}</label>
      {children}
    </div>
  );
};

export default FormGroup;