import React from "react";

type GameListProps = {
  value: string;
  onChange: (value: string) => void;
};

const GameList: React.FC<GameListProps> = ({ value, onChange }) => {
  const juegos = [
    "League of Legends",
    "Valorant",
    "Fortnite",
    "Minecraft",
    "Apex Legends",
    "Call of Duty",
  ];

  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full border rounded-lg p-2"
    >
      <option value="">-- Selecciona un juego --</option>
      {juegos.map((juego) => (
        <option key={juego} value={juego}>
          {juego}
        </option>
      ))}
    </select>
  );
};

export default GameList;