import React, { useState } from "react";
import Layout from "../components/Layout";
import FormGroup from "../components/FormGroup";
import GameList from "../components/GameList";

const ConcursoForm: React.FC = () => {
  const [nombre, setNombre] = useState("");
  const [edad, setEdad] = useState<number | "">("");
  const [nivel, setNivel] = useState("");
  const [ciudad, setCiudad] = useState("");
  const [gustaJuegos, setGustaJuegos] = useState(false);
  const [juegoFavorito, setJuegoFavorito] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(
      `¡Gracias por participar, ${nombre}!\n\nDetalles:\nEdad: ${edad}\nNivel: ${nivel}\nCiudad: ${ciudad}\n¿Le gustan los videojuegos?: ${
        gustaJuegos ? "Sí" : "No"
      }\nJuego favorito: ${juegoFavorito}`
    );
  };

  return (
    <Layout title="Formulario de Concurso de Videojuegos">
      <form onSubmit={handleSubmit}>
        <FormGroup label="Nombre y Apellidos">
          <input
            type="text"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            required
            className="w-full border rounded-lg p-2"
            placeholder="Ej: Juan Pérez"
          />
        </FormGroup>

        <FormGroup label="Edad">
          <input
            type="number"
            value={edad}
            onChange={(e) => setEdad(Number(e.target.value))}
            required
            min={10}
            className="w-full border rounded-lg p-2"
            placeholder="Ej: 18"
          />
        </FormGroup>

        <FormGroup label="Nivel educativo">
          <select
            value={nivel}
            onChange={(e) => setNivel(e.target.value)}
            required
            className="w-full border rounded-lg p-2"
          >
            <option value="">-- Selecciona --</option>
            <option value="Bachillerato">Bachillerato</option>
            <option value="FP">Formación Profesional</option>
            <option value="Universidad">Universidad</option>
          </select>
        </FormGroup>

        <FormGroup label="Ciudad desde donde participas">
          <input
            type="text"
            value={ciudad}
            onChange={(e) => setCiudad(e.target.value)}
            required
            className="w-full border rounded-lg p-2"
            placeholder="Ej: Madrid"
          />
        </FormGroup>

        <FormGroup label="¿Te gustan los videojuegos?">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={gustaJuegos}
              onChange={(e) => setGustaJuegos(e.target.checked)}
            />
            <span>Sí</span>
          </label>
        </FormGroup>

        <FormGroup label="Selecciona tu juego favorito">
          <GameList value={juegoFavorito} onChange={setJuegoFavorito} />
        </FormGroup>

        <button
          type="submit"
          className="w-full mt-4 bg-indigo-600 text-white font-semibold py-2 rounded-lg hover:bg-indigo-700 transition"
        >
          Enviar participación
        </button>
      </form>
    </Layout>
  );
};

export default ConcursoForm;